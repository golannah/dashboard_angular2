const path  = require('path');
const mocksConfig = require(path.join(__dirname,'routes.json'));
let data  = {};
for (const key in mocksConfig) {
  if (mocksConfig.hasOwnProperty(key)) {
    const value = mocksConfig[key];
    const segments = value.split('-');
    const url  = segments.join('/');
    try{
      const routeData = require(path.join(__dirname,'data',url));
      const urlKey  = value.replace('/','');
      data[urlKey] = routeData;
    }
    catch(e){
      console.log(`Error occured when loading data for url${key}.Error:${e}`);
    }

  }
}
module.exports = () => {
  return data;
}
