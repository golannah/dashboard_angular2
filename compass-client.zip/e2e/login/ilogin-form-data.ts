export interface ILoginFormData {
 username: string;
 password: string;
}
