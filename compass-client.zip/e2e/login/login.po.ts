import { browser, by, element } from 'protractor';
import {ILoginFormData} from './ilogin-form-data';


export class LoginPage {
  navigateTo() {
    return browser.get('/');
  }

  setLoginFormData(formData: ILoginFormData) {

  }
}
