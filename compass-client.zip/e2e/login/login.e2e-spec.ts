import { LoginPage } from './login.po';

describe('Test login page', () => {
  let page: LoginPage;

  beforeEach(() => {
    page = new LoginPage();
  });

  it('should login with proper details', () => {
    page.navigateTo();
  });
});
