import {Component, OnInit} from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {validateEmail} from '../validators/email.validator';
import 'rxjs/add/operator/map';
import {AuthenticationService} from '../authentication.service';
import {get, flow} from 'lodash';
import {UserPreferencesService} from '../../core/services/user-preferences/user-preferences.service';
import {LocalStorageService} from 'ngx-webstorage';

@Component({
  selector: 'app-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss']
})
export class LoginComponent implements OnInit {
  public form: FormGroup;
  public username: string;
  public password: string;

  constructor(private router: Router,
              private authService: AuthenticationService,
              private userPreferencesService: UserPreferencesService,
              private localSt: LocalStorageService) {
    this.form = new FormGroup({
      email: new FormControl('', [Validators.required, validateEmail]),
      password: new FormControl('', [Validators.required])
    });
  }

  /**
   *  Login the user to the system
   */
  login() {
    this.authService.login(this.username, this.password, '')
      .subscribe(
        (data) => {
          this.userLoggedIn(data);
          this.decodeToken(data['token']);
        },
        err => console.log(err)
      );
  }

  /**
   * Handler  - after user succsefully logged in
   * @param data
   * @returns {boolean}
   */
  userLoggedIn(data) {
    return flow(this.parseData,
      this.saveToken.bind(this),
      this.redirectAfterLogin.bind(this)
    )(data);
  }

  /**
   * @param  - data returned from login response
   * @returns {string}  - user token
   */
  parseData(data) {
    const token = get(data, 'token', null);
    return token;
  }

  /**
   * @param token - user token
   * @returns {boolean} if token succesfully parsed
   */
  saveToken(token) {
    let userTokenSaved = false;
    if (token) {
      this.localSt.store('token', token);
      userTokenSaved = true;
    }
    return userTokenSaved;
  }

  /**
   * Redirect user if token successfully processed
   * @param isTokenSaved
   */
  redirectAfterLogin(isTokenSaved) {
    if (isTokenSaved) {
      this.router.navigate(['/main', 'dashboard']);
    }
  }

  decodeToken(token: string) {
    this.userPreferencesService.decodeToken(token);
  }


  ngOnInit() {
  }

}
