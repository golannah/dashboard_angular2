import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AuthenticationRoutes} from './authentication.routes';
import {LoginComponent} from './login/login.component';
import {ForgotPasswordComponent} from './forgot-password/forgot-password.component';
import {SharedModule} from '../shared/shared.module';
import {CoreModule} from '../core/core.module';
import {AuthenticationService} from './authentication.service';
import {AuthCanActivateGuard} from './guard/AuthCanActivateGuard';
import { ParticlesModule } from 'angular-particle';
import {TabsModule} from 'ngx-bootstrap';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AuthenticationRoutes,
    SharedModule,
    CoreModule,
    ParticlesModule,
    TabsModule

  ],
  providers: [
    AuthenticationService,
    AuthCanActivateGuard
  ],
  declarations: [LoginComponent, ForgotPasswordComponent]
})

export class AuthenticationModule {
}
