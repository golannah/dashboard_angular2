import {Injectable} from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {LocalStorageService} from 'ngx-webstorage';
import {jwt_decode} from 'jwt-decode';
import {isUndefined} from 'lodash';
import {JwtDecode} from '../core/pipes/jwt-decode/jwtdecode.pipe';


@Injectable()
export class AuthenticationService {
  constructor(private http: HttpClient, private localStorageService: LocalStorageService, private jwtDecoder: JwtDecode) {
  }
  login(username: string, password: string, domainName: string = '') {
    const url = `${environment.compassApiBaseUrl}/security/auth/login`;
    const body = new URLSearchParams();
    body.append('username', username);
    body.append('password', password);
    body.append('domainName', '');
    const httpHeaders = new HttpHeaders()
      .set('Content-Type', 'application/x-www-form-urlencoded');
    return this.http.post(url, body.toString(), {headers: httpHeaders});
  }

  getToken(): string {
    return this.localStorageService.retrieve('token');
  }

  getTokenExpirationDate(token: string): Date {
    const decoded = this.jwtDecoder.transform(token);
    if (isUndefined(decoded.exp)) {
      return null;
    }
    const date = new Date(0);
    date.setUTCSeconds(decoded.exp);
    return date;
  }

  isTokenExpired(token?: string): boolean {
    if (!token) {
      token = this.getToken();
    }
    if (!token) {
      return true;
    }
    const date = this.getTokenExpirationDate(token);
    if (isUndefined(date)) {
      return false;
    }
    return !(date.valueOf() > new Date().valueOf());

  }

  logout() {
    const url = `${environment.compassApiBaseUrl}/security/auth/logout`;
    return this.http.post(url, {});
  }
}
