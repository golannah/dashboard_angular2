import { TestBed, inject } from '@angular/core/testing';

import { AuthenticationService } from './authentication.service';

describe('AuthenticationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthenticationService]
    });
  });

  it('should be created', inject([AuthenticationService], (service: AuthenticationService) => {
    expect(service).toBeTruthy();
  }));

  it('should return expired on not valid token', inject([AuthenticationService], (service: AuthenticationService) => {
    const tokenIsValid  = service.isTokenExpired('fdsfsfdsffsfsd');
    expect(tokenIsValid).toEqual(false);
  }));
});
