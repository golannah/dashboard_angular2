import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CUSTOM_ELEMENTS_SCHEMA, ErrorHandler, Injectable, NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {AppComponent} from './app.component';
import {SharedModule as AppSharedModule} from './shared/shared.module';
import {AuthenticationModule} from './authentication/authentication.module';
import {MainModule} from './main/main.module';
import {AppRoutes} from './app.routes';
import {CoreModule} from './core/core.module';
import {TranslateModule} from '@ngx-translate/core';
import {HttpClientModule} from '@angular/common/http';
import {TooltipModule, TabsModule} from 'ngx-bootstrap';
import {ModalModule} from 'ngx-bootstrap/modal';
import {BsModalService} from 'ngx-bootstrap';
import {GlobalErrorHandlerService} from './errorHandling/global-error-handler.service';
import {TranslateModuleConfiguration} from './shared/constants/translate-module.config';
import {ModalComponent} from './shared/components/modal-component/modal-component.component';
import {MomentModule} from 'angular2-moment';


@NgModule({
  declarations: [
    AppComponent,
    ModalComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutes,
    CoreModule.forRoot(),
    TooltipModule.forRoot(),
    TabsModule.forRoot(),
    AppSharedModule,
    MainModule,
    AuthenticationModule,
    ModalModule.forRoot(),
    TranslateModule.forRoot(TranslateModuleConfiguration),
    MomentModule
  ],
  providers: [
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandlerService
    },
    BsModalService
  ],
  entryComponents: [ModalComponent],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {
}
