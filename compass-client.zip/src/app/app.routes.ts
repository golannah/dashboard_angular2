import {ActivatedRouteSnapshot, CanActivate, RouterModule, RouterStateSnapshot} from '@angular/router';
import {Injectable, ModuleWithProviders} from '@angular/core';
import {LoginComponent} from './authentication/login/login.component';

const routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component : LoginComponent
  },
  {
    path: 'main',
    loadChildren:
      'app/main/main.module#MainModule'
  },

];


export const AppRoutes: ModuleWithProviders = RouterModule.forRoot(routes);
