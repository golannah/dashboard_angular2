import {Component} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

// import {MenuService} from './shared/menus/menus.service';

@Component({
  selector: 'app-root',
  template: `
    <router-outlet></router-outlet>
    <app-loader-indicator></app-loader-indicator>
  `,
  styleUrls: ['./app.component.scss']
  // ,
  // providers: [MenuService]
})
export class AppComponent {

  constructor(private translate: TranslateService) {
    translate.addLangs(['en', 'fr']);
    translate.setDefaultLang('en');

    translate.use('en');
  }

}
