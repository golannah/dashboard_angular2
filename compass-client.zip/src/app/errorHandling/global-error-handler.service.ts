import {ErrorHandler, Injectable, Injector} from '@angular/core';
import {HttpErrorResponse} from '@angular/common/http';
import {ModalComponent} from '../shared/components/modal-component/modal-component.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import {Router} from '@angular/router';
import {LoggerService} from '../core/services/logging/logger.service';
@Injectable()
export class GlobalErrorHandlerService implements ErrorHandler {
  private modalService: BsModalService;
  private routerService: Router;
  private loggerService: LoggerService;
  private bsModalRef: BsModalRef;
  private HTTP_FORBIDDEN = 403; HTTP_UNAUTHORIZED = 401;
  constructor(private injector: Injector) {
  }
  private get modal(): BsModalService {
    if (!this.modalService) {
      this.modalService = this.injector.get(BsModalService);
    }
    return this.modalService;
  }

  private get router(): Router {
    if (!this.routerService) {
      this.routerService = this.injector.get(Router);
    }
    return this.routerService;
  }
  private get logger(): LoggerService{
    if (!this.loggerService) {
      this.loggerService = this.injector.get(LoggerService);
    }
    return this.loggerService;
  }

  openErrorModal(error: HttpErrorResponse) {
    this.bsModalRef = this.modal.show(ModalComponent);
    this.bsModalRef.content.title = 'Error occured';
    this.bsModalRef.content.innerHtml = `<div>${error.message}</div>`;
  }
  handleError(error) {
    this.openErrorModal(error);
    this.logger.error('Unexpected error occured', error);
    // IMPORTANT: Rethrow the error otherwise it gets swallowed
    // TODO  : check if we want to rethrow or swallow
   throw error;
  }

}
