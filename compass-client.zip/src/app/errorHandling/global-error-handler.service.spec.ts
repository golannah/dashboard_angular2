import { TestBed, inject } from '@angular/core/testing';
import { GlobalErrorHandlerService } from './global-error-handler.service';
import {HttpErrorResponse} from '@angular/common/http';

describe('GlobalErrorHandlerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GlobalErrorHandlerService]
    });
  });

  it('should be created', inject([GlobalErrorHandlerService], (service: GlobalErrorHandlerService) => {
    expect(service).toBeTruthy();
  }));
});
