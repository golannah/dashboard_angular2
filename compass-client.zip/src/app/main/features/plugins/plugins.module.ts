import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PluginListComponent } from './plugin-list/plugin-list.component';
import {PluginFilterComponent} from './plugin-filter/plugin-filter.component';
import {DropdownModule, MultiSelectModule} from 'primeng/primeng';
import {FormsModule} from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    MultiSelectModule,
    FormsModule
  ],
  exports: [PluginFilterComponent],
  declarations: [PluginListComponent, PluginFilterComponent]
})
export class PluginsModule { }
