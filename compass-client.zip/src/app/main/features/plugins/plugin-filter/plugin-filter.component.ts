import {Component, OnInit} from '@angular/core';
import {SelectItem} from 'primeng/primeng';
import {PluginsService} from '../../../../core/services/plugins/plugins.service';
import {map, get} from 'lodash';


@Component({
  selector: 'app-plugin-filter',
  templateUrl: './plugin-filter.component.html',
  styleUrls: ['./plugin-filter.component.scss']
})
export class PluginFilterComponent implements OnInit {

  public pluginsList = [];
  public plugins: SelectItem[];
  public selectedPlugins: SelectItem;

  constructor(private pluginService: PluginsService) {
  }

  getSelectedPlugins() {
    return get(this.selectedPlugins, 'value.id');
  }

  ngOnInit() {
    /*Disable until problem will be found*/
    this.pluginService.getPlugins().subscribe((data) => {
      this.pluginsList = data;
      this.plugins = <SelectItem []> map(this.pluginsList, (plugin) => {
        const selectItem = {
          label: plugin.label,
          value: plugin,
          color : plugin.color,
          icon : plugin.icon
        }
        return selectItem;
      });
    });
  }

}
