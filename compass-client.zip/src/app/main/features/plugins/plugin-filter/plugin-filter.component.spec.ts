import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PluginFilterComponent } from './plugin-filter.component';

describe('PluginFilterComponent', () => {
  let component: PluginFilterComponent;
  let fixture: ComponentFixture<PluginFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PluginFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PluginFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
