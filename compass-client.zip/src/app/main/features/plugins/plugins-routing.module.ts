import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PluginListComponent } from './plugin-list/plugin-list.component';

const routes: Routes = [
  {
    path: 'plugins',
    component: PluginListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PluginsRoutingModule {
}
