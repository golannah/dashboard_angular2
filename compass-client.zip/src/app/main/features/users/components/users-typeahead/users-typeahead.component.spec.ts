import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersTypeaheadComponent } from './users-typeahead.component';

describe('UsersTypeaheadComponent', () => {
  let component: UsersTypeaheadComponent;
  let fixture: ComponentFixture<UsersTypeaheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsersTypeaheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersTypeaheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
