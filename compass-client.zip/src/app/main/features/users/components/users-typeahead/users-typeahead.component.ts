import {Component, DoCheck, Input, OnInit, SimpleChanges} from '@angular/core';
import {UsersService} from '../../users.service';
import {UsersList} from '../../model/users-list';
import {User} from '../../model/user';
import {SelectItem} from 'primeng/primeng';
import {map} from 'lodash';

@Component({
  selector: 'app-users-typeahead',
  templateUrl: './users-typeahead.component.html',
  styleUrls: ['./users-typeahead.component.scss']
})
export class UsersTypeaheadComponent implements OnInit {

  public userList: UsersList = new UsersList();
  public selectedUsers: SelectItem [];
  public users: SelectItem[];
  @Input () selectStyle = {'width' : '500px'}
  constructor(private userService: UsersService) {
  }

  ngOnInit() {
    this.userService.getAllUsers().subscribe(data => {
      this.userList = data;
      this.users =  <SelectItem []> map(this.userList.content, (user: User) => {
         const selectItem = {
           label : user.username,
           value : user
        }
        return selectItem;

      });

    });
  }

  getSelectedUsers() {
    return map(this.selectedUsers, (user: any) =>   user );
  }


}
