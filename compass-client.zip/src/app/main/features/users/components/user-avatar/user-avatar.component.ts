import {Component, Input, OnChanges, OnInit} from '@angular/core';
import {User} from '../../model/user';
import {get} from 'lodash';

@Component({
  selector: 'app-user-avatar',
  templateUrl: './user-avatar.component.html',
  styleUrls: ['./user-avatar.component.scss']
})
export class UserAvatarComponent implements OnInit, OnChanges {

  @Input()public user: any = {};
  @Input()public showTitle =  true;
  public assignedUser: any;
  constructor() { }

  ngOnInit() {
    this.assignedUser = get(this.user, 'assignedUser', {});
  }

  ngOnChanges(changes) {
    this.assignedUser = get(this.user, 'assignedUser', {});
  }
  getUserUrl() {
    return get(this.user, 'assignedUser.imageUrl' , null);
  }

  getUserStyle() {
      return  '';
  }

}
