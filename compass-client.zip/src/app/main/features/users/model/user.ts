export class User {
  public identifier: string;
  public username: string;
  public pictureUrl: string;
}
