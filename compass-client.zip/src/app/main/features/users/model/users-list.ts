import {List} from '../../../../core/model/list';
import {User} from './user';

export class UsersList extends List<User> {
  public content: User [];
  constructor() {
   super();
  }
}
