import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {UsersService} from './users.service';
import { UsersTypeaheadComponent } from './components/users-typeahead/users-typeahead.component';
import { UserAvatarComponent } from './components/user-avatar/user-avatar.component';
import {DropdownModule} from 'primeng/primeng';
import {MultiSelectModule} from 'primeng/primeng';
import {FormsModule} from '@angular/forms';
import {CoreModule} from '../../../core/core.module';

@NgModule({
  imports: [
    CommonModule,
    DropdownModule,
    MultiSelectModule,
    FormsModule,
    CoreModule
  ],
  declarations: [UsersTypeaheadComponent, UserAvatarComponent],
  exports : [UsersTypeaheadComponent, UserAvatarComponent],
  providers  : [UsersService]
})
export class UsersModule {

}
