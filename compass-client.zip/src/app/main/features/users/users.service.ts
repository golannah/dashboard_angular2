import { Injectable } from '@angular/core';
import {User} from './model/user';
import {LocalStorageService} from 'ngx-webstorage';
import {UsersList} from './model/users-list';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../../environments/environment';

@Injectable()
export class UsersService {

  constructor(private localSt: LocalStorageService, private http: HttpClient) {}
  static getCurrentUser () {
      const currentUser  = new User();
      currentUser.identifier = '10';
      currentUser.username = 'John';
      return currentUser;
  }
  getAllUsers() {
    const url = `${environment.compassApiBaseUrl}/security/usermanagement/identifications `;
    return this.http.get<UsersList>(url);
  }

}
