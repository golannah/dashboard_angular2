import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-threats-filter',
  templateUrl: './threats-filter.component.html',
  styleUrls: ['./threats-filter.component.scss']
})
export class ThreatsFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
