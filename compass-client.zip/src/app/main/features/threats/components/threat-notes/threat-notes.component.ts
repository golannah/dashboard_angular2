import {Component, Injector, OnInit} from '@angular/core';
import {ThreatsService} from '../../services/threats.service';
import {Router, ActivatedRoute} from '@angular/router';
import {ThreatNote} from '../../model/threat-note';
import {User} from '../../../users/model/user';
import {UsersService} from '../../../users/users.service';
import {BsModalRef, BsModalService} from 'ngx-bootstrap';
import {ThreatNotesModalComponent} from './threat-notes-modal/threat-notes-modal.component';
import {orderBy, takeRight} from 'lodash';


@Component({
  selector: 'app-threat-notes',
  templateUrl: './threat-notes.component.html',
  styleUrls: ['./threat-notes.component.scss']
})
export class ThreatNotesComponent implements OnInit {

  public noteItem: ThreatNote[];
  public allNoteItem: ThreatNote[];
  public userData: User;
  public threatId: string;
  public noteItemCount: number;
  private modalService: BsModalService;
  private bsModalRef: BsModalRef;
  public referrerFooterText: string;

  constructor(private activeRoute: ActivatedRoute,
              private router: Router,
              private threatsService: ThreatsService,
              private injector: Injector) {
  }

  getNotes() {

    this.activeRoute.paramMap
      .subscribe(params => {
        this.threatId = params.get('id');

        this.threatsService.getThreatNotes(this.threatId)
          .subscribe(
            (data) => {
              const dataContent = data['content'];
              orderBy(dataContent, ['timestamp'], ['asc']);
              this.noteItemCount = dataContent.length;
              this.referrerFooterText = `see ${this.noteItemCount} previous notes >`;
              if ( this.noteItemCount > 3) {
                this.allNoteItem = dataContent;
                this.noteItem = <ThreatNote []>takeRight(dataContent, 3);
              } else {
                this.noteItem = this.allNoteItem = dataContent;
              }
            },
            err => console.log(err)
          );
      });
  }

  onNoteAdded() {
    this.getNotes();
  }

  ngOnInit() {
    this.getNotes();
    this.userData = UsersService.getCurrentUser();
    this.userData.pictureUrl = 'iVBORw0KGgoAAAANSUhEUgAAACgAAAAeCAYAAABe3VzdAAAKGUlEQVRYR7WYe2wc13WHv3tndmbfy93lSzJFiQ+RXD5ESZHl2omVKjEi1Ani1DESGWj8T1sEbYG0hQI0dhNbcgM3KAIEdRG0TVA0aIwkTlE7sGWnaVLZtSJKokSRpUSKlBSJFsWHSEp87IO7OzP3FrO03CRVLNpGB5j9Y3HvPR9+55zfmRnB+7y6urqijmW1BKHVFmZKo2VJuVmEuKKCwfGR48dvvp8Q4r1sbm5uTtiR+F4jYP5ewA7sMQ2zRpddsgtL5JYXEWYZpCIcCufSqfRAwA59P0vg5cFjx6bfbbx3BdjQ0BCKxFMfNwLmF23L2iUkRr6QY2lxkfxyFoolgobGDmo8FJ7WxGIxauo3EQwnL3tKfzOfz393cHBwfr2g6wZs6+lpFto4IKXxmG1ZUdcpMTM9yc0bN9BKIQWEDINUNEIsGgIUhdU8q6USiUSC+o0NmOGoV/D0T4uu+dWhE0ePrQdyXYCtnZ07DCmflML4pG3bsljIM31tkpWVlV+J4R8Ws0PYpgXKoyoWJGwb5FbzaMsivaEBO5akpDijtXr69NGjLwH6nUDvCNjR0dODoZ9CyodNQwq0y/zsLEvzC0StAP4BtnbYvrWBWDhE/8VrXF5crcQ0A5Jw2CKARipNorqW9MZGhBXE9dxT2nUPDfT1vfKeAbd0ddUHkV+Whvy8YRgmwiOXW8TJZQkhcfMlEoEyD324l089sAeQPH/4NZ5/fZDJvIf7VmRTQMAQhONR6hqbiFal0Z6H1uoVV6lDQ319p34T5DspKNs6e/5YGuIrhmHUGlIiBKyu3CB7c5Fi0SMqXR7Z28tjD/8OtakUrquYm79B//GTjI9fYnnVY/pmjvPXl5gpeYQjERq2NFFVXYvWHp5yXdf1/lYXi18dGhpauh3kbwRsbuu62zTFQWnIB6WUSGlgygC5uXlmpq+S9xx2bqnjzx/dxz07uyg5YFtBpNBkF+dYmZ8ju5JjpVhkdGKGH50cZyrrsbm5lXi6Bscr+4B4So+i1MGB48f/9d0AitZM159JKZ6SUiYqgEIirRAL83PMXr2C8lx2t9TxRw99kA90t2MFo9jhOJ6CQm6JwvJNnMIy0lCsevDCf5zhZ8NXiW7ZSjCWRCkHtIfylNZK/V3WdZ8e6++/8euQt1WwYilKH0SIz/lwQgiEkFiWQTF3k6mr18jlSjywo4XP/+79tDU1ghHBE0HMQACKeXI35nCcVYygJBKPc/r8JN//r7PM6zCRSAh8BT2NUsq/j2rXPXimv//I+gAzmQeRxkEhxN0VQCnRQhDXDr2pEOlohOGxKzQ3VPOZhz/KaqnI6eFRxq/MUi46dG/eQPfWFqJVVZSFxo5HuLSwwgvHRplZLhG2ZMWGPKV9BX0fnVV4hwZP9P/DugBbOrr+0JAclNLYaBgSaRjkSyWaY0G+sHc3LfXVvDp0Bjse4t6ebs6PjPPST15nerlIvuixKRXgY3t6WcnDyNgEGzbXUo6nGJrJUXbB0LKinvYcv5PRWmvQX3vuO9/5ViaTmfhlyNumuLWj83EphQ9oVQClwXKhwG+1NLB/az3Z6TeZkZKm7gw9rc0ITI68cZyXXj2C8jwefeQj1NXEefb5nzGzXOahPR+gbITpn5inoBQIiedq8FyU8io8Gv2PX3vmmcP7Hnjg8B0Bt2YyfwXiy75ypmniW0yh7NCUivHZ7s101sUZnpoir1zu3bWduzY2MHVtmrPDY1Sna+ntbmZ2doJ/f/0kRryOre1tDI1d4/jl67jmGo7nKnQF0K9BX0Cee+KJL7382Uce+eEdAVs7Op8Rgsd/GVAhKBZL7Otu4Q/23cOJoROcvzjGfdt7qU6mkMIgbNkk47VEI3EWF6d4c+o6oUSagin43tFhBiYXiYdtDNd9q0HWAP0EI/jelw4ceHn//v0/uCNgW1fXk2g/xVIYplFR0G+UVVejCjkyKYNtm2OkEza1NTVUJ9K42SJzb15Fa5NIaiO2bRK1IL2hjktF+KfXBrly/SaJkI30vDVAv/4qgNpP8T8/9uij3zpw4MCJOwJuzXT/qZQ8JYRMrtXg2hTxfwqOS3VA8YmeOlo3JXFMQSoaJyYjmDrA2MWLHOk7RU1tPfftbKd2SyM/n1zl8LFzOKUipmlUulcr75bFrKmI/kZeiEOXBwaW7wjY3tn5GS3kQSlk5n8BBZ7wMwEd6SA76i0SiRDBeJigVJRyJVwVImCGka5TUb0qGcWNxPnRqYucHp8kEonAmu/d6l48rwJaUJpDI0Nn/mZdNtPe3r1Lm/g++PG1MScrAf3Gc8ur9G6I0hxZZSmfJ1mzgSobcIooQhSXFUauSHVNFW07uplxLZ57fZCrCzeJhPyFa9ca5JpRe0qNaE8fGj079H/G3W1tpm7btkjC018RUnxRCmH4k8QwDJQQzM9Mc++WFHsyNbxxaoTlguCe7s20bqxCFctMXb1OwIrQsWs7geoqDg9c5NjoLKYGU6hKN9wCq4D69ae8HzhKHbpw9uzYuhT0F7Vlej4lRUXFXj/Nfv0ZwQjpkMmHm8J03RXjyKlRXu4bZVNtHZ+8t5uGVIiFuXnMcJjN27cxfG2VF98YYKW0StgMohVvp3atMfCbZFGjnz4/PPys1johhFi8Yw36C7q6ulJa85eGGfiC1toslkpEk7VsqU+ze6NJptZicmaeV944x8CFaerqU9zd3kh1QFJTF8eJxTjy37NcWyoSDPmjTaK1XOtcH+6tG61f1I4+OD5+blhrnVw3oA+5c+fO+z2Pp+bmr390ZSXL1kw36VSaJFnu76ihsSrI5YkZXjk5wslfzFBl2ezpaKRzWyvHLkzy89EJ6jfdRTKWxCl5lMpvjza0b87oy2gOXTg/8i8V+363gH7BBIORzzme8yRat7S0trOhsRnPdeisj/DBlgSWzjNwbpxjJy8QDYX59EN7UAGLb794lKErU0TDNrFwglAiRSQW9Skol8u4jruihf76ipTfmB8Zyb1XQH+fZYejv6+c8uM1dfWbWjt6KWuD5blJdjSE+O3tDXjZZSbOTxBOhIk3pPnxiYv8Z/+Vii3Z0qi8FpW0IhSJUpVMEo1Gc6Zh/n1Z8vVfDA/P3aq596Lgrb0BYH+q/q4ntm/f3SGUYuB0H7Uhg4c/1ENbfZCyk8OzI/zk9BV+3DeK4629rPlP2ZZlUyoXKZdL/l8LwLPAN4Ff+erwfgArwdINDbt3ZHb+xY2FGw+Ojg0Ha8KSfb2NfGRXK6FIiNdODvPC0RGmsmtw/vQJ2Eblach/slJKnfI896+BV4Hyr1vK+wZ868AI8DERsP+kt73pvk/fvy20szmNZUhGL13jpZ/2c/bSDFnfuw1JwDZdtDpbKrrfVop/A95O6f8X4K1zjfamptZPfKhr7967M/ckbdnqllX1zMKS7Bs8tfza4PjE+IwzoIV1xHEK54C1l+V3uG6n4P8AlWKzW6rXfPYAAAAASUVORK5CYII=';
  }

  /**
   * This method return a reference to a modal service.
   * The service can render components into the bsModalRef that passed via show() function.
   * @returns {BsModalService} - the reference to the modal service.
   */
  private get modal(): BsModalService {
    if (!this.modalService) {
      this.modalService = this.injector.get(BsModalService);
    }
    return this.modalService;
  }

  /**
   * This function show the note item -modal, and inject relevant data into it.
   */
  openThreatNotesModal() {
    this.bsModalRef = this.modal.show(ThreatNotesModalComponent);
    this.bsModalRef.content.title = 'Notes';
    this.bsModalRef.content.noteItemsModalData = this.allNoteItem;
  }


}
