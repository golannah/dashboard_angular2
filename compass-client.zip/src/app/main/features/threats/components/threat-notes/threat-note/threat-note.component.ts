import {Component, Input, OnInit} from '@angular/core';
import {SafePipe} from '../../../../../../shared/pipes/safe/safe.pipe';

@Component({
  selector: 'app-threat-note',
  templateUrl: './threat-note.component.html',
  styleUrls: ['./threat-note.component.scss']
})
export class ThreatNoteComponent implements OnInit {

  @Input() noteData;

  constructor(private safePipe: SafePipe) {
  }

  ngOnInit() {
    if (this.noteData.img) {
      this.noteData.img = this.safePipe.transform(this.noteData.img, 'resourceUrl');
    }
    else {
      this.noteData.img = null;
    }

  }

}
