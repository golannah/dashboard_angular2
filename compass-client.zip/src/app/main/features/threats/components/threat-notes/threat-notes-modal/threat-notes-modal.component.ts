import {Component, Injector, OnInit} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';

@Component({
  selector: 'app-threat-notes-modal',
  templateUrl: './threat-notes-modal.component.html',
  styleUrls: ['./threat-notes-modal.component.scss']
})

/**
 * This class represents a modal component that view the extended data of the host activity in the site.
 */
export class ThreatNotesModalComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public title: string;
  public noteItemsModalData;

  /**
   * @param {Injector} injector - the injector instance that gets the injected BsModalRef.
   */
  constructor(private injector: Injector) {
    this.bsModalRef = this.injector.get(BsModalRef);
  }
  ngOnInit() {

  }

}
