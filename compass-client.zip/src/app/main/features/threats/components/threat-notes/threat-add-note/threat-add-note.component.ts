import {Component, Input, OnInit, ViewChild, AfterViewInit, ElementRef, Output, EventEmitter} from '@angular/core';
import {ThreatsService} from '../../../services/threats.service';
import {ToastrService} from 'ngx-toastr';
import {ThreatNote} from '../../../model/threat-note';


@Component({
  selector: 'app-threat-add-note',
  templateUrl: './threat-add-note.component.html',
  styleUrls: ['./threat-add-note.component.scss']
})
export class ThreatAddNoteComponent implements AfterViewInit {

  @Input() userData;
  @Input() threatId;
  @Output () onNoteAdded = new EventEmitter();
  @ViewChild('noteTxt') noteTxt: ElementRef;
  private note: ThreatNote;

  constructor(private threatsService: ThreatsService, private toastr: ToastrService) {

    this.note = {
      userName: null,
      note: null,
      img: null
    };
  }

  addNote() {
    this.note.note = this.noteTxt.nativeElement.value;
    this.threatsService.addThreatNotes(this.threatId, this.note).subscribe(data => {
      this.toastr.success('Threat note successfully added');
      this.onNoteAdded.emit(data);
    });
  }

  ngAfterViewInit() {

    this.note.userName = this.userData.userName;
    this.note.img = this.userData.pictureUrl;

  }

}
