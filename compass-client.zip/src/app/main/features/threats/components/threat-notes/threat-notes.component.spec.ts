import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreatNotesComponent } from './threat-notes.component';

describe('ThreatNotesComponent', () => {
  let component: ThreatNotesComponent;
  let fixture: ComponentFixture<ThreatNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreatNotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreatNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
