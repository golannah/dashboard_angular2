import {AfterContentInit, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {ThreatList} from '../../model/threat-list';
import {ThreatsService} from '../../services/threats.service';
import {LoggerService} from '../../../../../core/services/logging/logger.service';
import {Router} from '@angular/router';
import {get, map,  invoke} from 'lodash';
import {BsModalRef, BsModalService, de} from 'ngx-bootstrap';
import {ModalComponent} from '../../../../../shared/components/modal-component/modal-component.component';
import {CategoriesService} from '../../../../../core/services/categories/categories.service';
import {ThreatBase} from '../../model/threat.base';
import {Menu, MenuItem} from 'primeng/primeng';
import {AssignThreatComponent} from '../assign-threat/assign-threat.component';
import {CloseThreatComponent} from '../close-threat/close-threat.component';
import {ThreatsFilter} from '../../model/threats-filter';
import {DateRangePickerComponent} from '../../../../../shared/components/date-range-picker/date-range-picker.component';
import {PluginFilterComponent} from '../../../plugins/plugin-filter/plugin-filter.component';
import {CategoryFilterComponent} from '../../../../../shared/components/category-filter/category-filter.component';
import {UsersTypeaheadComponent} from '../../../users/components/users-typeahead/users-typeahead.component';
import {ThreatsStatusFilterComponent} from '../threats-status-filter/threats-status-filter.component';
import {Threat} from '../../model/threat';



@Component({
  selector: 'app-threat-list',
  templateUrl: './threat-list.component.html',
  styleUrls: ['./threat-list.component.scss']
})
export class ThreatListComponent implements OnInit, AfterContentInit {
  public threatList: ThreatList = new ThreatList();
  public totalText: string;
  public filterOptions: ThreatsFilter = new ThreatsFilter();
  shareDataModal: BsModalRef;
  assignThreatModal: BsModalRef;
  closeThreatModal: BsModalRef;
  items: MenuItem[];
  selectedThreat: ThreatBase;
  public isFilterOpen = false;
  public options = {page: 0, sort: 'risk' , order: 1};


  @ViewChild(DateRangePickerComponent) dateRangePicker: DateRangePickerComponent;
  @ViewChild(PluginFilterComponent) pluginFilterComponent: PluginFilterComponent;
  @ViewChild(CategoryFilterComponent) categoryFilterComponent: CategoryFilterComponent;
  @ViewChild(ThreatsStatusFilterComponent) threatsStatusComponent: ThreatsStatusFilterComponent;
  @ViewChild(UsersTypeaheadComponent) userSelectComponent: UsersTypeaheadComponent;

  constructor(private threatService: ThreatsService,
              private logger: LoggerService,
              private router: Router,
              private modalService: BsModalService,
              private categoriesService: CategoriesService) {
  }

  ngOnInit() {
    this.threatService.getThreats().subscribe(data => {
      this.threatList = data;
      this.totalText = `Total of ${this.threatList.totalElements} threats`;
      this.items = [
        {
          label: 'Assign', command: (event) => {
          event.originalEvent.stopPropagation();
          this.assignThreat();
        }
        },
        {
          label: 'Close', command: (event) => {
          event.originalEvent.stopPropagation();
          this.closeThreat();
        }
        }
      ];
    });
  }

  ngAfterContentInit() {
  }

  /**
   * @param rowData -  ThreatBase object.
   * @returns {string}
   */
  getCategories(rowData) {
    return this.categoriesService.getCategoryProperties(rowData.categories);
  }

  /**
   * @param rowData -  ThreatBase object.
   * @returns {string}
   */
  getPlugins(rowData) {
    return 'CheckPoint';
  }

  /**
   * Get assets for display
   * @param threat
   */
  getAssets(threat) {
    return get(threat, 'assets[0].ip');
  }

  /**
   * Callback for share threat data service
   */
  shareThreatData() { // TODO  : create modal for sharing data
    this.shareDataModal = this.modalService.show(ModalComponent);
    this.shareDataModal.content.title = 'Share threat data';
  }

  /**
   * Callback for assign threat service
   */
  assignThreat() {

    this.assignThreatModal = this.modalService.show(AssignThreatComponent);
    this.assignThreatModal.content.threat = this.selectedThreat;
    this.assignThreatModal.content.onThreatAssigned = () => this.threatService.getThreats(this.filterOptions).subscribe((data) => {
      this.threatList = data;
    });
  }

  /**
   * Mark threat as closed.
   * @param {ThreatBase} threat
   */
  closeThreat() {
    this.closeThreatModal = this.modalService.show(CloseThreatComponent);
    this.closeThreatModal.content.threat = this.selectedThreat;
    this.closeThreatModal.content.onThreatClosed = () => this.threatService.getThreats(this.filterOptions).subscribe((data) => {
      this.threatList = data;
    });
  }

  /**
   * Calback for trigger threat callback
   * @param isFilterOpen - boolean
   */
  showFilter(isFilterOpen: boolean) {
    this.isFilterOpen = isFilterOpen;
  }

  /**
   * Callback for search threats
   * @param {event} - event from search
   */
  searchThreats(event) {
    const query: string = get(event, 'data');
    this.logger.log('Search query is:', query);
  }

  openMenu(threat: ThreatBase, menu: Menu, event: any) {
    this.selectedThreat = threat;
    menu.toggle(event);
    event.stopPropagation();
  }

  getStatus(state) {
    return state.replace('_', ' ');
  }

  onRowSelect(tableRowSelected) {
    const threatId = get(tableRowSelected, 'data.id');
    this.router.navigate([`main/threats/${threatId}`]);
  }
  filterApply() {
    this.filterOptions.assignedUser = map(this.userSelectComponent.getSelectedUsers(), selectValue => {
      return get(selectValue, 'assignedUser.identifier');
    });
    this.filterOptions.plugins = map(this.pluginFilterComponent.getSelectedPlugins(), selectValue => {
      return get(selectValue, 'value.id');
    });
    this.filterOptions.category = map(this.categoryFilterComponent.getSelectedCategories(), selectValue => {
      return get(selectValue, 'value.id');
    });
    const selectedDateRange = this.dateRangePicker.getSelectedRange();
    if (selectedDateRange) {
      this.filterOptions.from = invoke(selectedDateRange, 'startTimestamp.valueOf');
      this.filterOptions.to = invoke(selectedDateRange, 'endTimestamp.valueOf');
    }

    this.filterOptions.state = this.threatsStatusComponent.getSelectedStatus();

    this.filterOptions.category  = this.categoryFilterComponent.getSelectedCategories();

    this.threatService.getThreats(this.filterOptions).subscribe((data) => {
        this.threatList  = data;
    });


  }
  public onPageChanged(page: number) {
    this.options.page = page;
    this.threatService.getThreats(this.filterOptions, this.options).subscribe(data => {
      this.threatList = data;
    });
  }

  getUser(threat: Threat) {
    return get(threat, 'threatMetadataDTO.assignInfo', {} );
  }

  onThreatsSort(event) {
    this.options.sort = get(event, 'fieldName', 'risk');
    this.options.order  = get(event, 'order', 1);
    this.threatService.getThreats(this.filterOptions, this.options).subscribe(data => {
      this.threatList = data;
    });
  }
  filterResetToDefault() {
    this.filterOptions = new ThreatsFilter();
    this.threatService.getThreats(this.filterOptions).subscribe(data => {
      this.threatList = data;
    });

  }

}
