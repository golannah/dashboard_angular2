import {Component, AfterViewInit} from '@angular/core';
import {ThreatList} from '../../model/threat-list';
import {Router, ActivatedRoute} from '@angular/router';
import 'rxjs/add/operator/switchMap';
import {ThreatsService} from '../../services/threats.service';
import {Menu, MenuItem} from 'primeng/primeng';
import * as moment from 'moment';
import {ThreatDetails} from '../../model/threat-details';
import {PluginsService} from '../../../../../core/services/plugins/plugins.service';
import {SafePipe} from '../../../../../shared/pipes/safe/safe.pipe';

@Component({
  selector: 'app-threats',
  templateUrl: './threats.component.html',
  styleUrls: ['./threats.component.scss']
})
export class ThreatComponent implements AfterViewInit {

  public threatList: ThreatList = new ThreatList();
  public threatId: string;
  public eventRange: any;
  public threatDetails: ThreatDetails;
  public plugins: any[];
  public managementData: any;
  public totalText: string;
  items: MenuItem[];

  constructor(private activeRoute: ActivatedRoute,
              private router: Router,
              private threatsService: ThreatsService,
              private pluginsService: PluginsService,
              private safePipe: SafePipe) {
  }

  ngAfterViewInit() {

    this.activeRoute.paramMap
      .subscribe(params => {
        this.threatId = params.get('id');
        this.threatsService.getThreatDetails(this.threatId)
          .subscribe(
            (data) => {

              this.managementData = {
                state: data.threatMetadataDTO.stateInfo.state,
                assignInfo: data.threatMetadataDTO.assignInfo,
                changeStateBy: data.threatMetadataDTO.stateInfo.changeStateBy,
                closingReason: data.threatMetadataDTO.stateInfo.closingReason,
                date: data.threatMetadataDTO.stateInfo.timestamp
              };
              this.threatDetails = data;

              this.plugins = this.pluginsService.getPluginProperties(this.threatDetails.plugins, ['label', 'icon']);
              this.plugins[0].icon = this.safePipe.transform(this.plugins[0].icon, 'resourceUrl');

              this.eventRange = {
                firstEvent: moment(this.threatDetails.startTime),
                lastEvent: moment(this.threatDetails.endTime)
              };

              this.getAggregatedEvents();
            },
            err => console.log(err)
          );
      });
    this.items = [{label: 'Report a threat'}];
  }

  getAggregatedEvents() {

    this.threatsService.getThreatAggregatedEvents(this.threatId)
      .subscribe(
        (data) => {
          this.threatList = data;
          this.totalText = `Events (${this.threatList.totalElements} total)`;
        },
        err => console.log(err)
      );
  }

  openMenu(menu: Menu, event: any) {

    menu.toggle(event);
    event.stopPropagation();
  }

  public onCategorySelected(val) {

    this.router.navigate(['main/events'], {queryParams: {category: val.name}});
  }
}
