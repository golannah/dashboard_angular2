import {Component, OnInit} from '@angular/core';
import {AppConstants} from '../../../../../shared/constants/app-constants';
import {values, map, get} from 'lodash';
import {SelectItem} from 'primeng/primeng';
import {LoggerService} from '../../../../../core/services/logging/logger.service';

@Component({
  selector: 'app-threats-status-filter',
  templateUrl: './threats-status-filter.component.html',
  styleUrls: ['./threats-status-filter.component.scss']
})
export class ThreatsStatusFilterComponent implements OnInit {

  public statusList: SelectItem [];
  public selectedStatuses: string [];

  constructor(private logger: LoggerService) {
    this.statusList = values<SelectItem []>(AppConstants.THREAT_STATUS).map((status: any) => {
      const selectItem = {
        label: status.label,
        value: status.value
      }
      return selectItem;
    });
  }

  ngOnInit() {
  }
  public getSelectedStatus() {
    return  this.selectedStatuses;
  }
}
