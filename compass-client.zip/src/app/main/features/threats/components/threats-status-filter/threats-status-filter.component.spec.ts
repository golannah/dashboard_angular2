import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreatsStatusFilterComponent } from './threats-status-filter.component';

describe('ThreatsStatusFilterComponent', () => {
  let component: ThreatsStatusFilterComponent;
  let fixture: ComponentFixture<ThreatsStatusFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreatsStatusFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreatsStatusFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
