import {Component, Injector, OnInit, ViewChild} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';
import {ThreatBase} from '../../model/threat.base';
import {User} from '../../../users/model/user';
import {ThreatNote} from '../../model/threat-note';
import {ThreatsService} from '../../services/threats.service';
import {ThreatClosingReason} from '../../enums/threat-closing-reason.enum';
import {ThreatStateInfo} from '../../model/threat-state-info';
import {AddNoteComponent} from '../../../../../shared/components/add-note/add-note.component';
import {UsersService} from '../../../users/users.service';
import {SelectItem} from 'primeng/primeng';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-close-threat',
  templateUrl: './close-threat.component.html',
  styleUrls: ['./close-threat.component.scss']
})
export class CloseThreatComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public threat: ThreatBase;
  public currentUser: User;
  public note: ThreatNote = new ThreatNote();
  public closingReason: any = ThreatClosingReason.NOT_NANDLED;
  @ViewChild(AddNoteComponent) noteComponent: AddNoteComponent;
  public closingOptions: SelectItem [];
  constructor(private injector: Injector, private threatService: ThreatsService, private toastr: ToastrService) {
    this.bsModalRef = this.injector.get(BsModalRef);
    this.currentUser = UsersService.getCurrentUser();
    this.closingOptions = this.buildOptions();
  }
  public appyClicked() {
    this.closeThreat(this.threat);
  }
  public closeThreat(threat: ThreatBase) {
      const threatCloseInfo = new ThreatStateInfo();
      threatCloseInfo.closingReason = this.closingReason;
      threatCloseInfo.note = this.noteComponent.getNote();
      this.threatService.closeThreat(threat.id, threatCloseInfo).subscribe(data => {
          this.bsModalRef.hide();
          this.toastr.success(`Threat #  ${threat.id} is closed!`);
          this.bsModalRef.content.onThreatClosed();
      }, error => {

      });
  }

  buildOptions() {
    const selectItems: SelectItem [] = [];
    const notHandled = {label : 'Not Handled', value : ThreatClosingReason.NOT_NANDLED};
    const falsePoistive = {label : 'False Positive', value : ThreatClosingReason.FALSE_POSITIVE};
    const notInterested = {label : 'Not Interested', value : ThreatClosingReason.NOT_INTERESTING};
    selectItems.push(notHandled);
    selectItems.push(falsePoistive);
    selectItems.push(notInterested);
    return selectItems;
  }

  ngOnInit() {
  }

}
