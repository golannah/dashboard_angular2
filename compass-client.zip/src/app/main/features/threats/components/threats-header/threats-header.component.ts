import { Component, OnInit } from '@angular/core';
import {ThreatList} from '../../model/threat-list';

@Component({
  selector: 'app-threats-header',
  templateUrl: './threats-header.component.html',
  styleUrls: ['./threats-header.component.scss']
})
export class ThreatsHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
