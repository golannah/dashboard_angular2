import {Component, Injector, OnInit, ViewChild} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';
import {ThreatBase} from '../../model/threat.base';
import {ThreatsService} from '../../services/threats.service';
import {User} from '../../../users/model/user';
import {ThreatNote} from '../../model/threat-note';
import {AddNoteComponent} from '../../../../../shared/components/add-note/add-note.component';
import {UsersTypeaheadComponent} from '../../../users/components/users-typeahead/users-typeahead.component';
import {SelectItem} from 'primeng/primeng';
import {ToastrService} from 'ngx-toastr';
import {get,map} from 'lodash';

@Component({
  selector: 'app-assign-threat',
  templateUrl: './assign-threat.component.html',
  styleUrls: ['./assign-threat.component.scss']
})
export class AssignThreatComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public threat: ThreatBase;
  public users: SelectItem [] ;
  public note: ThreatNote = new ThreatNote();
  @ViewChild(AddNoteComponent) noteComponent: AddNoteComponent;
  @ViewChild(UsersTypeaheadComponent) userComponent: UsersTypeaheadComponent;
  constructor(private injector: Injector, private threatService: ThreatsService, private toastr: ToastrService) {
    this.bsModalRef = this.injector.get(BsModalRef);
  }
  public appyClicked() {
    this.note.note = this.noteComponent.getNote();
    this.users = this.userComponent.getSelectedUsers();
    this.assignThreat(this.users, this.threat, this.note);
  }

  public assignThreat(users: any, threat: ThreatBase, note: ThreatNote) {
    this.threatService.assignThreat(users, threat, note).subscribe(data => {
      this.bsModalRef.hide();
      const selectedUserName = get(this.users,'[0].username','');
      this.toastr.success(`Threat assigned to user : ${selectedUserName}`);
      this.bsModalRef.content.onThreatAssigned();
    });
  }

  ngOnInit() {
  }

}
