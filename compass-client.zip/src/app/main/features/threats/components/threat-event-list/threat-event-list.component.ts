import {Component, Input, OnInit} from '@angular/core';
import {map} from 'lodash';
import {CategoriesService} from '../../../../../core/services/categories/categories.service';
import {get} from 'lodash'
import {SafePipe} from '../../../../../shared/pipes/safe/safe.pipe';
import {PluginsService} from '../../../../../core/services/plugins/plugins.service';

@Component({
  selector: 'app-event-threat-list',
  templateUrl: './threat-event-list.component.html',
  styleUrls: ['./threat-event-list.component.css']
})
export class ThreatEventListComponent implements OnInit {

  @Input() threatList;
  public plugins: any[];

  constructor(private categoriesService: CategoriesService,
              private pluginsService: PluginsService,
              private safePipe: SafePipe) {
  }


  ngOnInit() {
  }

  getCategories(rowData) {
    const categoryIndex = map(this.categoriesService.categoriesList, 'value').indexOf(rowData.category);
    return this.categoriesService.categoriesList[categoryIndex]['displayName'];
  }

  getPlugins(rowData) {

   this.plugins = this.pluginsService.getPluginProperties(rowData.plugins, ['label', 'icon']);
    return this.safePipe.transform(this.plugins[0].icon, 'resourceUrl');
  }

  getAssets(event){
    console.log('Event',event);
    return get(event, 'assets[0].ip');
  }

}
