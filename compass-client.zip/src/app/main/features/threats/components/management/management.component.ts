import {Component, Input, OnInit} from '@angular/core';
import {ThreatManagment} from '../../model/threat-managment';
import * as moment from 'moment';

@Component({
  selector: 'app-management',
  templateUrl: './management.component.html',
  styleUrls: ['./management.component.scss']
})
export class ManagementComponent implements OnInit {
  @Input() managementData: ThreatManagment;
  public stateDate: string;
  public assignInfoDate: string;
  private startDate: any;
  private endDate: any;

  constructor() {

  }

  ngOnInit() {


    this.startDate = moment(this.managementData.date);
    this.endDate = moment();
    this.stateDate = this.startDate.from(this.endDate);

    if(this.managementData.assignInfo){

      this.startDate = moment(this.managementData.date);
      this.endDate = moment();
      this.assignInfoDate = this.startDate.from(this.endDate);

    }

  }

}
