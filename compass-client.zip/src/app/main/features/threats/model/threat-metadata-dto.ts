import {ThreatAssignInfo} from './threat-assign-info';
import {ThreatStateInfo} from './threat-state-info';

/**
 * Data Transfer Object for Therat MetaData
 */
export class ThreatMetadataDto {
  public assignInfo: ThreatAssignInfo;
  public stateInfo: ThreatStateInfo;

}
