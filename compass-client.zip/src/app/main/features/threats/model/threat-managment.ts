export class ThreatManagment {
 state: string;
 date: number;
 assignInfo: any;
 closingReason: string;
 changeStateBy: any;
}
