import {ThreatBase} from './threat.base';
import {List} from '../../../../core/model/list';
export class ThreatList extends List<ThreatBase> {
 public content: ThreatBase[];
  constructor() {
      super();
  }
}
