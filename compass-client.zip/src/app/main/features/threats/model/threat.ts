import {ThreatBase} from './threat.base';
export class Threat extends ThreatBase {
}
