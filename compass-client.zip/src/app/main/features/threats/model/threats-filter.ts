export class ThreatsFilter {
  constructor() {
    this.risk = [1, 10];
  }
  public from: number;
  public to: number;
  public name: string;
  public risk: number [];
  public state: string [];
  public showFalseAlarms: boolean;
  public showNotIteresting: boolean;
  public plugins: string [];
  public category: string [];
  public assignedUser: string [];
}
