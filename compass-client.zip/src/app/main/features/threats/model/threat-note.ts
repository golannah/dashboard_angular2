export class ThreatNote {
  public id?: number;
  public userName: string;
  public note: string;
  public img: string;
  public timestamp?: any;
}
