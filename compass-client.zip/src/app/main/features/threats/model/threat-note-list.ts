import {ThreatNote} from './threat-note';
import {List} from '../../../../core/model/list';

export class ThreatNoteList extends List<ThreatNote> {
  public content: ThreatNote [];
}
