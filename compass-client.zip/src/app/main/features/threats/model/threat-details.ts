export class ThreatDetails {
  public plugins: number[];
  public risk: number;
  public attackers: any[];
  public startTime: number;
  public endTime: number;
  public assets: string[];
  public name: string;
  public state: string;
  public stateTime: number;
}
