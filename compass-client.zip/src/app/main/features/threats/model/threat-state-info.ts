/**
 * Class representing the Threat State Info
 */
export class ThreatStateInfo {
  public closingReason: number;
  public note: string;
}
