/**
 * Details of Threat assignment
 */
export class ThreatAssignInfo {
  assignTimestamp: string;
  assignedUser: string;
  note: string;
}
