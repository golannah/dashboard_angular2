import {ThreatMetadataDto} from './threat-metadata-dto';
import {Asset} from '../../../../core/model/asset';

/**
 * Class representing the base for every type of threat data
 */
export class ThreatBase {
  constructor() {
    this.threatMetadataDTO = new ThreatMetadataDto();
  }
  public id: number;
  public assets: Asset [];
  public startTimestamp: number;
  public endTimestamp: number;
  public name: string;
  public risk: number;
  public assignedTo: string;
  public closedBy: string;
  public closingReason: string;
  public closingTimestamp: number;
  threatMetadataDTO: ThreatMetadataDto;
  eventCount: number;
}

