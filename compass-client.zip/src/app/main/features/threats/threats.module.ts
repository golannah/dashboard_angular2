import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ThreatListComponent} from './components/threat-list/threat-list.component';
import {routing} from './threats.routes';
import {ThreatComponent} from './components/threat/threat.component';
import {TooltipModule, TabsModule} from 'ngx-bootstrap';
import {TranslateModule} from '@ngx-translate/core';
import {ConfirmDialogModule, MenuModule, SliderModule} from 'primeng/primeng';
import {HttpClientModule} from '@angular/common/http';
import {CoreModule} from '../../../core/core.module';
import {SharedModule} from '../../../shared/shared.module';
import {ThreatsHeaderComponent} from './components/threats-header/threats-header.component';
import {ThreatsFilterComponent} from './components/threats-filter/threats-filter.component';
import {ThreatsService} from './services/threats.service';
import {PluginsModule} from '../plugins/plugins.module';
import {AssignThreatComponent} from './components/assign-threat/assign-threat.component';
import {CloseThreatComponent} from './components/close-threat/close-threat.component';
import {UsersModule} from '../users/users.module';
import {FormsModule} from '@angular/forms';
import {ThreatsStatusFilterComponent} from './components/threats-status-filter/threats-status-filter.component';
import {ManagementComponent} from './components/management/management.component';
import {ThreatNoteComponent} from './components/threat-notes/threat-note/threat-note.component';
import {ThreatAddNoteComponent} from './components/threat-notes/threat-add-note/threat-add-note.component';
import {ThreatEventListComponent} from './components/threat-event-list/threat-event-list.component';
import { ThreatNotesComponent } from './components/threat-notes/threat-notes.component';
import {ThreatNotesModalComponent} from './components/threat-notes/threat-notes-modal/threat-notes-modal.component';


@NgModule({
  imports: [
    CommonModule,
    routing,
    SharedModule,
    CoreModule,
    HttpClientModule,
    ConfirmDialogModule,
    TranslateModule,
    TooltipModule,
    TabsModule,
    PluginsModule,
    MenuModule,
    UsersModule,
    FormsModule,
    SliderModule
  ],

  declarations: [
    ThreatListComponent,
    ThreatComponent,
    ThreatsHeaderComponent,
    ThreatsFilterComponent,
    AssignThreatComponent,
    CloseThreatComponent,
    ThreatsStatusFilterComponent,
    ManagementComponent,
    ThreatNoteComponent,
    ThreatAddNoteComponent,
    ThreatEventListComponent,
    ThreatNotesComponent,
    ThreatNotesModalComponent
  ],
  providers: [
    ThreatsService
  ],
  entryComponents: [
    AssignThreatComponent,
    CloseThreatComponent,
    ThreatNotesModalComponent
  ]
})
export class ThreatsModule {
}
