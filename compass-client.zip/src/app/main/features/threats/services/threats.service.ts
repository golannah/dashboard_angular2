import {Injectable} from '@angular/core';
import {HttpClient, HttpEvent} from '@angular/common/http';
import {environment} from '../../../../../environments/environment';
import {ThreatsFilter} from '../model/threats-filter';
import {User} from '../../users/model/user';
import {ThreatBase} from '../model/threat.base';
import {ThreatNote} from '../model/threat-note';
import {ThreatList} from '../model/threat-list';
import {ThreatDetails} from '../model/threat-details';
import {ThreatStateInfo} from '../model/threat-state-info';
import {get, map} from 'lodash';

@Injectable()
/**
 * Threats service responsible for basic operations on threats
 */
export class ThreatsService {
  constructor(private httpClient: HttpClient) {
  }

  private getFilterParams() {
    return {};
  }

  /**
   * Get avalibale threats - filter by user filter and paginated
   * @param {ThreatsFilter} filter
   * @param options - pagionation and date time parameters taken from url state
   * @returns {Observable<Object>}  - collection of ThreatList
   * */
  getThreats(filter?: ThreatsFilter, options?: any) {
    const url = `${environment.compassApiBaseUrl}/threats/threats`;
    if (filter) {
      const filterRequest = this.getFilterRequest(filter);
      return this.httpClient.post<ThreatList>(url, filterRequest);
    }
    else {
      return this.httpClient.get<ThreatList>(url);
    }

  }

  /**
   * Get spesific threat summary details
   * @param {number} threatId
   */
  getThreatDetails(threatId: string) {
    const url = `${environment.compassApiBaseUrl}/threats/threats/${threatId}`;
    return this.httpClient.get<any>(url);
  }

  /**
   * Get spesific threat Aggregated Events details
   * @param {number} threatId
   */
  getThreatAggregatedEvents(threatId: string) {
    const url = `${environment.compassApiBaseUrl}/threats/threats/${threatId}/events`;
    return this.httpClient.get<any>(url);
  }

  /**
   * Close threat and provide close details
   * @param {number} threatId
   * @param body
   * @returns {Observable<Object>}
   */
  closeThreat(threatId: number, threateStateInfo: ThreatStateInfo) {
    const url = `${environment.compassApiBaseUrl}/threats//threats/${threatId}/close`;
    return this.httpClient.put<any>(url, threateStateInfo);
  }

  /**
   * Get threat notes , optionally paginated
   * @param {number} threatId
   * @param options
   * @returns {Observable<Object>}
   */
  getThreatNotes(threatId: string, options?: any) {
    const url = `${environment.compassApiBaseUrl}/threats/threats/${threatId}/notes`;
    return this.httpClient.get<any>(url);
  }

  /**
   * Add notes to threat
   * @param {number} threatId
   * @param {ThreatNote[]} notes
   * @returns {Observable<Object>}
   */
  addThreatNotes(threatId: number, threatNote: ThreatNote) {
    const url = `${environment.compassApiBaseUrl}/threats/threats/${threatId}/notes`;
    const noteRequest = {note: threatNote.note};
    return this.httpClient.post<any>(url, noteRequest);
  }

  /**
   * Assign threat to spesific user
   * @param {User} user
   * @param {ThreatBase} threat
   * @param {ThreatNote} note
   * @returns {Observable<Object>}
   */
  assignThreat(users: string [], threat: ThreatBase, note: ThreatNote) {
    const url = `${environment.compassApiBaseUrl}/threats/threats/${threat.id}/assign`;
    const body = {
      assignedUser: {userId: get(users, '[0].identifier')},
      note: note.note || ''
    };
    return this.httpClient.put(url, body);
  }

  /**
   * Free search of threats by query
   * @param {string} query
   * @returns {Observable<Object>}
   */
  search(query: string) {
    const url = `${environment.compassApiBaseUrl}/threats/search/${query}`;
    return this.httpClient.get<ThreatList>(url);
  }

  getFilterRequest(filter: ThreatsFilter) {
    const filterRequest: any = {
      filters:
        [
          {'@type': 'risk', 'from': filter.risk[0], 'to': filter.risk[1]}

        ]
    };

    if(filter.from && filter.to) {
      filterRequest.filters.push({'@type': 'time', 'from': filter.from, 'to': filter.to});
    }
    if(get(filter, 'assignedUser.length', 0)) {
      filterRequest.filters.push({'@type': 'assignedUser', 'userIds': filter.assignedUser } );
    }

    if(get(filter, 'plugins.length', 0)) {
      filterRequest.filters.push({'@type': 'plugin', 'plugins' : filter.plugins});
    }

    if(get(filter, 'category.length', 0)) {
      filterRequest.filters.push({'@type': 'category', 'categories' : filter.category});
    }

    if(filter.state) {
      filterRequest.filters.push({'@type': 'status', 'threatStates': [filter.state] });
    }

    return filterRequest;
  }
}
