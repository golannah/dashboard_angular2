import { TestBed, inject } from '@angular/core/testing';

import { ThreatsService } from './threats.service';

describe('Threats.ServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ThreatsService]
    });
  });

  it('should be created', inject([ThreatsService], (service: ThreatsService) => {
    expect(service).toBeTruthy();
  }));
});
