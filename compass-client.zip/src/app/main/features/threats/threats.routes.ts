import { Route, RouterModule } from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {ThreatComponent} from './components/threat/threat.component';
import {ThreatListComponent} from './components/threat-list/threat-list.component';

export const ThreatsRoutes: Route[] = [
  {
    path: 'threats',
    component: ThreatListComponent,
    data: { title: 'THREATS.TITLE' }
  },
  {
    path: 'threats/:id',
    component: ThreatComponent,
    data: { title: 'THREAT_DETAILS.TITLE' }
  }
];


export const routing: ModuleWithProviders = RouterModule.forChild(ThreatsRoutes);

