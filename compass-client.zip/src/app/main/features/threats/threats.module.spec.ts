import { ThreatsModule } from './threats.module';

describe('ThreatsModule', () => {
  let threatsModule: ThreatsModule;

  beforeEach(() => {
    threatsModule = new ThreatsModule();
  });

  it('should create an instance', () => {
    expect(threatsModule).toBeTruthy();
  });
});
