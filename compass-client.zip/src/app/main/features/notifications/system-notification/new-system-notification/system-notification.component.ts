import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-notification',
  templateUrl: './system-notification.component.html',
  styleUrls: ['./system-notification.component.css']
})
export class SystemNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
