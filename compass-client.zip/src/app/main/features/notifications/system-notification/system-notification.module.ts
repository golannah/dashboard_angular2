import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SystemNotificationListComponent } from './system-notificaiton-list/system-notification-list.component';
import { SystemNotificationComponent } from './new-system-notification/system-notification.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SystemNotificationListComponent, SystemNotificationComponent]
})
export class SystemNotificationModule { }
