import { SystemNotificationModule } from './system-notification.module';

describe('SystemNotificationModule', () => {
  let systemNotificationModule: SystemNotificationModule;

  beforeEach(() => {
    systemNotificationModule = new SystemNotificationModule();
  });

  it('should create an instance', () => {
    expect(systemNotificationModule).toBeTruthy();
  });
});
