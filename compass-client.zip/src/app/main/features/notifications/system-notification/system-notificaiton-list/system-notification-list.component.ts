import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-notification-list',
  templateUrl: './system-notification-list.component.html',
  styleUrls: ['./system-notification-list.component.css']
})
export class SystemNotificationListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
