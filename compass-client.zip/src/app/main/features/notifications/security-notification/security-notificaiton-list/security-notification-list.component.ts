import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-security-notification-list',
  templateUrl: './security-notification-list.component.html',
  styleUrls: ['./security-notification-list.component.css']
})
export class SecurityNotificationListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
