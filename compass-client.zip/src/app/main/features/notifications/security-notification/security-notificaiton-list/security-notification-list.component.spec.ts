import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecurityNotificationListComponent } from './security-notification-list.component';

describe('SecurityNotificationListComponent', () => {
  let component: SecurityNotificationListComponent;
  let fixture: ComponentFixture<SecurityNotificationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecurityNotificationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityNotificationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
