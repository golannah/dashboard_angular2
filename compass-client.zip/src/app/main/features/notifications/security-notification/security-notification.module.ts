import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewSecurityNotificationComponent } from './new-security-notification/new-security-notification.component';
import { SecurityNotificationListComponent } from './security-notificaiton-list/security-notification-list.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ NewSecurityNotificationComponent, SecurityNotificationListComponent]
})
export class SecurityNotificationModule { }
