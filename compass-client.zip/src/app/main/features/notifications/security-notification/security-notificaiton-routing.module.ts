import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SecurityNotificationListComponent } from './security-notificaiton-list/security-notification-list.component';

const routes: Routes = [
  {
    path: 'notifications',
    component: SecurityNotificationListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecurityNotificationsRoutingModule {
}
