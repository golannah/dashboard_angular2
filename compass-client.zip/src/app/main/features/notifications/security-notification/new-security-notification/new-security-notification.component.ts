import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-security-notification',
  templateUrl: './new-security-notification.component.html',
  styleUrls: ['./new-security-notification.component.css']
})
export class NewSecurityNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
