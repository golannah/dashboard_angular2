import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewSecurityNotificationComponent } from './new-security-notification.component';

describe('NewSecurityNotificationComponent', () => {
  let component: NewSecurityNotificationComponent;
  let fixture: ComponentFixture<NewSecurityNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewSecurityNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewSecurityNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
