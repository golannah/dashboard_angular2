import { SecurityNotificationModule } from './security-notification.module';

describe('SecurityNotificationModule', () => {
  let securityNotificationModule: SecurityNotificationModule;

  beforeEach(() => {
    securityNotificationModule = new SecurityNotificationModule();
  });

  it('should create an instance', () => {
    expect(securityNotificationModule).toBeTruthy();
  });
});
