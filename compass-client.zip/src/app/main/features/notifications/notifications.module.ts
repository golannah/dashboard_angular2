import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NotificationsRoutingModule } from './notificaitons-routing.module';
import { SecurityNotificationModule } from './security-notification/security-notification.module';
import { SystemNotificationModule } from './system-notification/system-notification.module';
import { NotificationsComponent } from './notifications/notifications.component';

@NgModule({
  imports: [
    CommonModule,
    SecurityNotificationModule,
    SystemNotificationModule
  ],
  exports: [
    NotificationsRoutingModule
  ],
  declarations: [NotificationsComponent]
})
export class NotificationsModule { }
