import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DashboardComponent} from './components/dashboard.component';
import {SharedModule} from '../../../shared/shared.module';
import {routing} from './dashboard.routes';
import {ConfirmationService, ConfirmDialogModule,ProgressBarModule} from 'primeng/primeng';
import {CoreModule} from '../../../core/core.module';
import {HttpClientModule} from '@angular/common/http';
import {TranslateModule} from '@ngx-translate/core';
import {TooltipModule} from 'ngx-bootstrap';
import {NgxChartsModule} from '@swimlane/ngx-charts';
import {VulnerabilityLevelComponent} from './components/vulnerability-level/vulnerability-level.component';
import {TopOpenThreatsComponent} from './components/top-open-threats/top-open-threats.component';
import {EventByRiskComponent} from './components/events-by-risk/event-by-risk.component';
import {DashboardService} from './services/dashboard.service';
import {MostTargetedAssetsComponent} from './components/most-targeted-assets/most-targeted-assets.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    routing,
    ConfirmDialogModule,
    ProgressBarModule,
    CoreModule,
    HttpClientModule,
    TranslateModule,
    TooltipModule,
    NgxChartsModule
  ],
  exports: [
    CommonModule
  ],
  declarations: [
    DashboardComponent,
    VulnerabilityLevelComponent,
    TopOpenThreatsComponent,
    EventByRiskComponent,
    MostTargetedAssetsComponent
  ],
  providers: [ConfirmationService, DashboardService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DashboardModule {
}

