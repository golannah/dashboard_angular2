import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {LocalStorageService} from 'ngx-webstorage';
import {DateRange} from '../model/date-range';
import {RangeList} from '../model/range-list';
import {Ranges} from '../enums/date-range.enum';
import {DateRangeOptions} from '../model/date-range-option';
import {Router} from '@angular/router';
import {isNull} from 'lodash';
import {TopActorsComponent} from '../../../../shared/components/top-actors/top-actors.component';
import {MostTargetedAssetsComponent} from './most-targeted-assets/most-targeted-assets.component';
import * as moment from 'moment';
import {TopOpenThreatsComponent} from './top-open-threats/top-open-threats.component';
import {ThreatsByCategoryComponent} from '../../../../shared/components/threats-by-category/threats-by-category.component';
import {VulnerabilityLevelComponent} from './vulnerability-level/vulnerability-level.component';
import {CategoriesService} from '../../../../core/services/categories/categories.service';
import {EventByRiskComponent} from './events-by-risk/event-by-risk.component';
import {AppConstants} from '../../../../shared/constants/app-constants';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['../components/dashboard.component.scss']
})
export class DashboardComponent implements OnInit, AfterViewInit {

  @ViewChild('topActors') topActorsCmp: TopActorsComponent;
  @ViewChild('mostTargeted') mostTargetedCmp: MostTargetedAssetsComponent;
  @ViewChild('topOpenThreats') topOpenThreatsCmp: TopOpenThreatsComponent;
  @ViewChild('threatsByCategory') threatsByCategoryCmp: ThreatsByCategoryComponent;
  @ViewChild('vulnerabilityLevel') vulnerabilityLevelCmp: VulnerabilityLevelComponent;
  @ViewChild('eventsByRisk') eventsByRiskCmp: EventByRiskComponent;

  public dashboardDateRange: DateRange;
  public dateRangeOptions: DateRangeOptions;
  private rangeList: RangeList;

  constructor(private localSt: LocalStorageService, private router: Router, private categoriesService: CategoriesService) {

  }

  ngOnInit() {
    this.initDateRangePicker();
  }

  initDateRangePicker() {
    this.rangeList = {
      'Yesterday': <any>[Ranges.YesterdayStart, Ranges.TodayEnd],
      'Last 3 Days': <any>[Ranges.Last3Days, Ranges.TodayEnd],
      'Last 7 Days': <any>[Ranges.Last7Days, Ranges.TodayEnd],
      'Last Month': <any>[Ranges.LastMonth, Ranges.TodayEnd],
    };

    if (isNull(this.localSt.retrieve('dashboardTimeRange'))) {
      this.dashboardDateRange = {
        startDate: Ranges.Last7Days,
        endDate: Ranges.TodayEnd,
        label: 'Last 7 days'
      };
      this.localSt.store('dashboardTimeRange', this.dashboardDateRange);
    } else {
      this.dashboardDateRange = {
        startDate: this.localSt.retrieve('dashboardTimeRange').startDate,
        endDate: this.localSt.retrieve('dashboardTimeRange').endDate,
        label: 'Last 7 days'
      };
    }

    this.dateRangeOptions = {
      locale: {format: 'YYYY-MM-DD'},
      alwaysShowCalendars: true,
      startDate: this.dashboardDateRange.startDate,
      endDate: this.dashboardDateRange.endDate,
      ranges: this.rangeList
    };
  }

  onDateRangeSelected(dateRange) {
    this.dashboardDateRange = {
      startDate: moment(dateRange.start).valueOf(),
      endDate: moment(dateRange.end).valueOf(),
      label: dateRange.label
    };
    this.localSt.store('dashboardTimeRange', this.dashboardDateRange);

    this.getWidgetsData();

  }

  onCategorySelected(category) {
    this.router.navigate(['main/threats'], {queryParams: {category: category.name}});
  }

  onActorSelected(actor) {
    this.router.navigate(['main/threats'], {queryParams: {actor: actor.attacker}});
  }

  getWidgetsData() {
    const from = moment(this.dashboardDateRange.startDate).valueOf();
    const to = moment(this.dashboardDateRange.endDate).valueOf();

    this.topActorsCmp.getData(from, to);
    this.mostTargetedCmp.getData(from, to);
    this.topOpenThreatsCmp.getData(from, to);
    this.threatsByCategoryCmp.getData(from, to);
    this.vulnerabilityLevelCmp.getData(from, to);
    this.eventsByRiskCmp.getData(from, to);
  }

  ngAfterViewInit() {
    this.getWidgetsData();

  /*  setInterval(() => {
      this.getWidgetsData();
    }, AppConstants.POLLING_INTERVAL);*/
  }

}
