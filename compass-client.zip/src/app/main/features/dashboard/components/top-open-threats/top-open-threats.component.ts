import {Component, Input, OnInit} from '@angular/core';
import {ThreatList} from '../../../threats/model/threat-list';
import {CategoriesService} from '../../../../../core/services/categories/categories.service';
import {map} from 'lodash';
import {DashboardService} from '../../services/dashboard.service';

import * as moment from 'moment';

@Component({
  selector: 'app-top-open-threats',
  templateUrl: './top-open-threats.component.html',
  styleUrls: ['./top-open-threats.component.scss']
})
export class TopOpenThreatsComponent implements OnInit {

  public threatList;

  constructor(private categoriesService: CategoriesService, private dashboardService: DashboardService) {
  }


  /**
   * @param rowData -  ThreatBase object.
   * @returns {string}
   */
  getCategories(rowData) {
    return this.categoriesService.getCategoryProperties(rowData.categories);
  }


  onRowSelect(tableRowSelected) {

  }


  getData(from: number, to: number) {
    this.dashboardService.getTopThreats(from, to)
      .subscribe(
        (data) => {
          this.threatList = data['content'];
        },
        err => console.log(err)
      );
  }

  ngOnInit() {
  }

}
