import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopOpenThreatsComponent } from './top-open-threats.component';

describe('TopOpenThreatsComponent', () => {
  let component: TopOpenThreatsComponent;
  let fixture: ComponentFixture<TopOpenThreatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopOpenThreatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopOpenThreatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
