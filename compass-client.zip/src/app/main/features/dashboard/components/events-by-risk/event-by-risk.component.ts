import {Component, OnInit} from '@angular/core';
import {DashboardService} from '../../services/dashboard.service';
import * as moment from 'moment';
import {map} from 'lodash';
import * as d3 from 'd3';

@Component({
  selector: 'app-event-by-risk',
  templateUrl: './event-by-risk.component.html',
  styleUrls: ['./event-by-risk.component.scss']
})

/**
 * This component represents the event-by-risk widget in the dashboard of the site.
 */
export class EventByRiskComponent implements OnInit {

  public totalCountValue = {
    total: 0,
    medium: 0,
    high: 0,
    critical: 0
  };

  public totalCountPercent = {
    medium: 0,
    high: 0,
    critical: 0
  };

  public chartData = [
    {
      'name': '',
      'series': []
    }
  ];
  public curve = d3.curveBasis;
  // options
  showXAxis = false;
  showYAxis = false;
  gradient = false;

  colorScheme = {
    domain: ['#edbd2b', '#ffae58', '#ff6165']
  };


  constructor(private dashboardService: DashboardService) {
  }

  getData(from: number, to: number) {

    const ticks = 5;

    this.dashboardService.getEventsBySeverity(from, to, ticks)
      .subscribe(
        (data) => {

          this.generateChartSeries(data);
        },
        err => console.log(err)
      );
  }

  generateChartSeries(data) {

    const mediumSeries = {
      name: 'Medium',
      series: map(data, (event) => {
        this.totalCountValue.medium += event['medium'];
        return {
          value: event['medium'],
          name: moment(event['startTimeStamp']).format('DD/MM')
        };
      })
    };
    const highSeries = {
      name: 'High',
      series: map(data, (event) => {
        this.totalCountValue.high += event['high'];
        return {
          value: event['high'],
          name: moment(event['startTimeStamp']).format('DD/MM')
        };
      })
    };
    const criticalSeries = {
      name: 'Critical',
      series: map(data, (event) => {
        this.totalCountValue.critical += event['critical'];
        return {
          value: event['critical'],
          name: moment(event['startTimeStamp']).format('DD/MM')
        };
      })
    };

    this.chartData = [];
    this.chartData.push(mediumSeries);
    this.chartData.push(highSeries);
    this.chartData.push(criticalSeries);

    this.totalCountValue.total =  this.totalCountValue.critical + this.totalCountValue.high + this.totalCountValue.medium;

    this.totalCountPercent = {
      critical: Math.round((this.totalCountValue.critical / this.totalCountValue.total) * 100),
      high: Math.round((this.totalCountValue.high / this.totalCountValue.total) * 100),
      medium: Math.round((this.totalCountValue.medium / this.totalCountValue.total) * 100),
    };
  }

  ngOnInit() {
  }
}
