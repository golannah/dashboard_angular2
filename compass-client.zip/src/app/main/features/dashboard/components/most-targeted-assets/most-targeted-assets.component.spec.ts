import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MostTargetedAssetsComponent } from './most-targeted-assets.component';

describe('MostTargetedAssetsComponent', () => {
  let component: MostTargetedAssetsComponent;
  let fixture: ComponentFixture<MostTargetedAssetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MostTargetedAssetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MostTargetedAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
