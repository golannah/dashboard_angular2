import {Component, Input, OnInit} from '@angular/core';
import {DashboardService} from '../../services/dashboard.service';

@Component({
  selector: 'app-most-targeted-assets',
  templateUrl: './most-targeted-assets.component.html',
  styleUrls: ['./most-targeted-assets.component.scss']
})
export class MostTargetedAssetsComponent implements OnInit {

  public mostTargetedAssetsList;

  constructor(private dashboardService: DashboardService) {
  }

  getData(from: number, to: number) {

    this.dashboardService.getMostTargetedAssets(from, to)
      .subscribe(
        (data) => {
          this.mostTargetedAssetsList = data['content'];
        },
        err => console.log(err)
      );
  }

  ngOnInit() {

  }
}
