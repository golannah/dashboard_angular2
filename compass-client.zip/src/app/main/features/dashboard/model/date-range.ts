export class DateRange {
   startDate: any;
   endDate: any;
   label: string;
}
