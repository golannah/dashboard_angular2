
import {TopActor} from './top-actor';
import {List} from '../../../../../core/model/list';
export class TopActorsList extends List<TopActor> {
  public content: TopActor[];
  constructor() {
    super();
  }
}
