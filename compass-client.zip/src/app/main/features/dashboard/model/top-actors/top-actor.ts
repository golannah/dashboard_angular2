
export class TopActor {
  public id: number;
  public countryId: number;
  public ip: string;
  public numOfThreats: number;
}
