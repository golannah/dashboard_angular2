import * as moment from "moment";
export class RangeList{

  'Yesterday': moment.Moment;
  'Last 3 Days': moment.Moment;
  'Last 7 Days': moment.Moment;
  'Last Month': moment.Moment

}
