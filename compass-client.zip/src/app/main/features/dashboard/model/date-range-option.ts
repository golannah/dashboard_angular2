import * as moment from 'moment';
import {RangeList} from './range-list';

export class DateRangeOptions {
  locale: any;
  alwaysShowCalendars: boolean;
  startDate?: moment.Moment;
  endDate?: moment.Moment;
  ranges: RangeList;
  opens?: string;
}

