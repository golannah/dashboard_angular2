import * as moment from 'moment';
 export enum Ranges {
  TodayStart = <any>moment().startOf('day') ,
  TodayEnd = <any>moment().endOf('day') ,
  YesterdayStart =  <any>moment().subtract(1, 'day').startOf('day'),
  YesterdayEnd =  <any>moment().subtract(1, 'day').endOf('day'),
  Last3Days =  <any>moment().subtract(3, 'day').startOf('day'),
  Last7Days =  <any>moment().subtract(7, 'day').startOf('day'),
  LastMonth =  <any>moment().subtract(1, 'month').startOf('day')
}
