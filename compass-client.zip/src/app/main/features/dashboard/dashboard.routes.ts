
import { Route, RouterModule } from '@angular/router';

import { DashboardComponent } from './components/dashboard.component';
import {ModuleWithProviders} from '@angular/core';

export const DashboardRoutes: Route[] = [
  {
    path: 'dashboard',
    data: { title: 'DASHBOARD.TITLE' },
    component: DashboardComponent
  }
];


export const routing: ModuleWithProviders = RouterModule.forChild(DashboardRoutes);



