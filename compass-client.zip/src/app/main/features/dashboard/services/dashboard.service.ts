import {Injectable} from '@angular/core';
import {environment} from '../../../../../environments/environment';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class DashboardService {

  constructor(private http: HttpClient) {
  }

  /**
   * @param {number} from
   * @param {number} to
   * @returns {Observable<Object>} - the observable object that the http service returns, and we will subscribe to it.
   */
  getTopThreats(from: number, to: number) {
    const url = `${environment.compassApiBaseUrl}/threats/widgets/topThreats?from=${from}&to=${to}`;
    return this.http.get(url);
  }

  /**
   * @param {number} from
   * @param {number} to
   * @returns {Observable<Object>} - the observable object that the http service returns, and we will subscribe to it.
   * */
  getThreatsByCategory(from: number, to: number) {
    const url = `${environment.compassApiBaseUrl}/threats/widgets/threatsByCategory?from=${from}&to=${to}`;
    return this.http.get(url);
  }

  /**
   *
   * @param {number} from
   * @param {number} to
   * @param {number} page
   * @param {number} size
   * @returns {Observable<Object>} - the observable object that the http service returns, and we will subscribe to it.
   * */
  getMostTargetedAssets(from: number, to: number, page?: number, size?: number) {
    const url = `${environment.compassApiBaseUrl}/threats/widgets/assets?from=${from}&to=${to}`;
    return this.http.get(url);
  }

  /**
   * @param {number} from
   * @param {number} to
   * @returns {Observable<Object>} - the observable object that the http service returns, and we will subscribe to it.
   * */
  getVulnerabilityLevel(from: number, to: number) {
    const url = `${environment.compassApiBaseUrl}/threats/widgets/vulnerability?from=${from}&to=${to}`;
    return this.http.get(url);
  }

  /**
   * @param {number} from
   * @param {number} to
   * @returns {Observable<Object>} - the observable object that the http service returns, and we will subscribe to it.
   * */
  getTopActors(from: number, to: number) {
    const url = `${environment.compassApiBaseUrl}/threats/widgets/attackers?from=${from}&to=${to}`;
    return this.http.get(url);
  }

  /**
   * @param {number} from
   * @param {number} to
   * @param {number} ticks
   * @returns {Observable<Object>} - the observable object that the http service returns, and we will subscribe to it.
   * */
  getEventsBySeverity(from: number, to: number, ticks: number) {
    const url = `${environment.compassApiBaseUrl}/threats/widgets/eventsBySeverity?from=${from}&to=${to}&ticks=${ticks}`;
    return this.http.get(url);
  }
}
