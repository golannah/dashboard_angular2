import { ActivityLogModule } from './activity-log.module';

describe('ActivityLogModule', () => {
  let activityLogModule: ActivityLogModule;

  beforeEach(() => {
    activityLogModule = new ActivityLogModule();
  });

  it('should create an instance', () => {
    expect(activityLogModule).toBeTruthy();
  });
});
