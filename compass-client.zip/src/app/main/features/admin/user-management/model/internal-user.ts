export class InternalUser {
  public userName: string;
  public fullName: string;
  public email: string;
  public phoneNumber: string;
  public userRoles: string[];
  public active: boolean;
}
