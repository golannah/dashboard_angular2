import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternalUserModalComponent } from './internal-user-modal.component';

describe('InternalUserModalComponent', () => {
  let component: InternalUserModalComponent;
  let fixture: ComponentFixture<InternalUserModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternalUserModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternalUserModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
