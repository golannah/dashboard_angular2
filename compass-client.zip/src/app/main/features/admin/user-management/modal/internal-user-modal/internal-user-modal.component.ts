import {Component, Injector, OnInit, ViewChild} from '@angular/core';
import {ThreatsService} from '../../../../threats/services/threats.service';
import {ToastrService} from 'ngx-toastr';
import {SelectItem} from 'primeng/primeng';
import {BsModalRef} from 'ngx-bootstrap';
import {InternalUser} from '../../model/internal-user';
import {FormGroup, FormControl} from '@angular/forms';
import {InternalUserService} from '../../services/internal-user.service';

@Component({
  selector: 'app-internal-user-modal',
  templateUrl: './internal-user-modal.component.html',
  styleUrls: ['./internal-user-modal.component.scss']
})


export class InternalUserModalComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public roles: string[];
  public internalUser: InternalUser;
  myform: FormGroup;


  /**
   if the modal is for edit or new user
   value can be : edit or new
   * */
  public operationType: string;
  public modalTitle: string;


  constructor(private injector: Injector,
              private toastr: ToastrService,
              private internalUserService: InternalUserService) {
    this.bsModalRef = this.injector.get(BsModalRef);


  }

  ngOnInit() {
    setTimeout(() => {

      if (this.operationType === 'add') {
        this.modalTitle = 'Add Internal User';


      } else {
        this.modalTitle = 'Edit Internal User';
      }

      if (this.operationType === 'add') {
        this.internalUser = {
          fullName: null,
          userName: null,
          email: null,
          userRoles: ['role1'],
          phoneNumber: null,
          active: null
        };
      }

      this.myform = new FormGroup({
        fullName: new FormControl(this.internalUser.fullName),
        userName: new FormControl(this.internalUser.userName),
        email: new FormControl(this.internalUser.email),
        password: new FormControl(),
        phoneNumber: new FormControl(this.internalUser.phoneNumber),
        roles: new FormControl(),
        active: new FormControl(this.internalUser.active)
      });

      this.roles = [...this.internalUser.userRoles];
    }, 0);

  }

  applyClicked() {
    if (this.operationType === 'edit') {
      this.internalUserService.editInternalUser(this.myform.value.userName, this.myform.value).subscribe(data => {
        this.bsModalRef.hide();
        this.toastr.success(`user ${this.myform.value.userName} is update`);
      });
    } else {
      this.internalUserService.addInternalUser(this.myform.value).subscribe(data => {
        this.bsModalRef.hide();
        this.toastr.success(`user ${this.myform.value.userName} is add`);
      });
    }

  }
}
