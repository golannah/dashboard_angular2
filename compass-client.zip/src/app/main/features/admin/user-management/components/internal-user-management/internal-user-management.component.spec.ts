import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignThreatComponent } from './assign-threat.component';

describe('AssignThreatComponent', () => {
  let component: AssignThreatComponent;
  let fixture: ComponentFixture<AssignThreatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignThreatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignThreatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
