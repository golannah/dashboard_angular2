import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldap',
  templateUrl: './ldap.component.html',
  styleUrls: ['./ldap.component.scss']
})
export class LdapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
