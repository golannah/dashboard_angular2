import {Component, OnInit} from '@angular/core';
import {InternalUserService} from '../../services/internal-user.service';
import {InternalUser} from '../../model/internal-user';
import {ConfirmationService, Menu, MenuItem} from 'primeng/primeng';
import {BsModalRef, BsModalService} from 'ngx-bootstrap';
import {InternalUserModalComponent} from '../../modal/internal-user-modal/internal-user-modal.component';
import {ToastrService} from 'ngx-toastr';


@Component({
  selector: 'app-internal-user-management',
  templateUrl: './internal-user-management.component.html',
  styleUrls: ['./internal-user-management.component.scss']
})
export class InternalUserManagementComponent implements OnInit {

  public internalUserList: InternalUser = new InternalUser;
  activeItems: MenuItem[];
  inActiveItems: MenuItem[];
  private internalUserModal: BsModalRef;
  private selectedUser: InternalUser;

  constructor(private internalUserService: InternalUserService,
              private confirmationService: ConfirmationService,
              private modalService: BsModalService,
              private toastr: ToastrService) {

  }

  ngOnInit() {
    this.internalUserService.getInternalUser().subscribe(data => {
      setTimeout(() => {
        this.internalUserList = data;
      }, 0);
      // this.totalText = `Total of ${this.eventList.totalElements}`;
    });

    this.activeItems = [
      {
        label: 'Active', command: (event) => {
          event.originalEvent.stopPropagation();
          this.changeActiveStatus();
        }
      },
      {
        label: 'Delete', command: (event) => {
          event.originalEvent.stopPropagation();
          this.confirmDeleteUser();
        }
      }
    ];

    this.inActiveItems = [
      {
        label: 'InActive', command: (event) => {
          event.originalEvent.stopPropagation();
          this.changeActiveStatus();

        }
      },
      {
        label: 'Delete', command: (event) => {
          event.originalEvent.stopPropagation();
          this.confirmDeleteUser();
        }
      }
    ];
  }

  changeActiveStatus() {
    this.selectedUser.active = !this.selectedUser.active;
    const activeStr = (this.selectedUser.active ? 'active' : 'in-active');
    this.internalUserService.editInternalUser(this.selectedUser.userName, this.selectedUser).subscribe(data => {
      this.toastr.success(`${ this.selectedUser.userName} is ${ activeStr}`);
    });

  }

  openMenu(user: InternalUser, menu: Menu, event: any) {
    menu.toggle(event);
    this.selectedUser = user;
    event.stopPropagation();
  }

  confirmDeleteUser() {

    this.confirmationService.confirm({
      message: `Are you sure that you want to delete:  ${ this.selectedUser.userName} ?`,
      accept: () => {
        this.internalUserService.deleteInternalUser(this.selectedUser).subscribe(data => {
          this.toastr.success(`${ this.selectedUser.userName} is delete`);
        });
      }
    });
  }

  onRowSelect(tableRowSelected) {
    this.internalUserModal = this.modalService.show(InternalUserModalComponent);
    this.internalUserModal.content.internalUser = tableRowSelected.data;
    this.internalUserModal.content.operationType = 'edit';
  }


  addUser(){
    this.internalUserModal = this.modalService.show(InternalUserModalComponent);
    this.internalUserModal.content.operationType = 'add';
  }

}


