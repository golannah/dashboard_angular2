import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {environment} from '../../../../../../environments/environment';
import {InternalUser} from '../model/internal-user';
import {EventStateInfo} from '../../../events/model/event-state-info';

@Injectable()
export class InternalUserService {
  constructor(private httpClient: HttpClient) {}
  private getFilterParams() {
    return {};
  }

  /**
   * Get avalibale internal user - filter by user filter and paginated
   * @param {internalUserFilter} filter
   * @param options - pagionation and date time parameters taken from url state
   * @returns {Observable<Object>}  - collection of InternalUserList
   * */
  getInternalUser() {
    const url = `${environment.compassApiBaseUrl}/security/users`;
    return this.httpClient.get<InternalUser>(url);
  }

  addInternalUser(internalUserData: InternalUser) {
    const url = `${environment.compassApiBaseUrl}/root/management/add`;
    return this.httpClient.post<InternalUser>(url, internalUserData);
  }

  editInternalUser(userName: string, internalUserData: InternalUser) {
    const url = `${environment.compassApiBaseUrl}/root/management/edit`;
    const params = new HttpParams().set('userName', userName);
    return this.httpClient.put<InternalUser>(url, internalUserData, {params: params});
  }
  deleteInternalUser(internalUserData: InternalUser) {
    const url = `${environment.compassApiBaseUrl}/root/management/delete`;
    return this.httpClient.post<InternalUser>(url, internalUserData);
  }

  /**
   * Free search of internal user by query
   * @param {string} query
   * @returns {Observable<Object>}
   */
  /*search(query: string) {
    const url = `${environment.compassApiBaseUrl}/events/search/${query}`;
    return this.httpClient.get<EventList>(url);
  }*/
}
