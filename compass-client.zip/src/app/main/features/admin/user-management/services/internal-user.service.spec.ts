import { TestBed, inject } from '@angular/core/testing';

import { InternalUserService } from './internal-user.service';

describe('InternalUserService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InternalUserService]
    });
  });

  it('should be created', inject([InternalUserService], (service: InternalUserService) => {
    expect(service).toBeTruthy();
  }));
});
