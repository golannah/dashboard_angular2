import {Route, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {InternalUserManagementComponent} from './components/internal-user-management/internal-user-management.component';
import {LdapComponent} from './components/ldap/ldap.component';


export const UserManagementRoutes: Route[] = [
  {
    path: 'internal-user-management',
    data: {title: 'Admin', subTitle: 'Internal User Management'},
    component: InternalUserManagementComponent
  },
  {
    path: 'ldap',
    data: {title: 'Admin', subTitle: 'LDAP'},
    component: LdapComponent
  }
];


export const routing: ModuleWithProviders = RouterModule.forChild(UserManagementRoutes);



