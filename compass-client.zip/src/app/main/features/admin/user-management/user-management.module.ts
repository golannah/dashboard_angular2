import {NgModule} from '@angular/core';
import {TabsModule} from 'ngx-bootstrap';
import {CommonModule} from '@angular/common';
import {UserManagementComponent} from './user-management.component';
import {routing} from './user-management.routes';
import {InternalUserManagementComponent} from './components/internal-user-management/internal-user-management.component';
import { LdapComponent } from './components/ldap/ldap.component';
import {InternalUserService} from './services/internal-user.service';
import {SharedModule} from '../../../../shared/shared.module';
import {ConfirmationService, ConfirmDialogModule, MenuModule} from 'primeng/primeng';
import { InternalUserModalComponent } from './modal/internal-user-modal/internal-user-modal.component';
import {ReactiveFormsModule} from '@angular/forms';
import {CoreModule} from '../../../../core/core.module';


@NgModule({
  imports: [
    CommonModule,
    CoreModule,
    TabsModule,
    routing,
    SharedModule,
    MenuModule,
    ConfirmDialogModule,
    ReactiveFormsModule
  ],
  declarations: [UserManagementComponent, InternalUserManagementComponent, LdapComponent, InternalUserModalComponent],
  providers: [
    InternalUserService,
    ConfirmationService
  ],
  entryComponents: [InternalUserModalComponent]

})
export class UserManagementModule { }
