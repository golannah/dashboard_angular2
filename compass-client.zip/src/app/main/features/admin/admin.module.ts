import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {UserManagementModule} from './user-management/user-management.module';
import {routing} from './admin.routes';

@NgModule({
  imports: [
    CommonModule,
    UserManagementModule,
    routing

  ],
  declarations: []
})
export class AdminModule { }
