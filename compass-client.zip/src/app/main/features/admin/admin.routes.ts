import {Route, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {UserManagementComponent} from './user-management/user-management.component';
import {UserManagementRoutes} from './user-management/user-management.routes';

export const AdminRoutes: Route[] = [
  {
    path: 'admin',
    children: [{
      path: 'user-management',
      data: {title: 'Admin', subTitle: 'User Management'},
      component: UserManagementComponent,
      children: [...UserManagementRoutes]
    }]
  }
];


export const routing: ModuleWithProviders = RouterModule.forChild(AdminRoutes);



