
import { Route, RouterModule } from '@angular/router';

import {ModuleWithProviders} from '@angular/core';
import {NetworkVisibilityComponent} from './components/network-visibility.component';

export const NetworkVisibilityRoutes: Route[] = [
  {
    path: 'network-visibility',
    data: { title: 'NETWORK_VISIBILITY.TITLE' },
    component: NetworkVisibilityComponent
  }
];


export const routing: ModuleWithProviders = RouterModule.forChild(NetworkVisibilityRoutes);



