import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../../../environments/environment';
import {Host} from '../model/host/host';
import {List} from '../../../../core/model/list';


@Injectable()
export class NetworkVisibilityService {

  constructor(private http: HttpClient) {
  }

  /**
   * @param {number} from
   * @param {number} to
   * @returns {Observable<Object>} - the observable object that the http service returns, and we will subscribe to it.
   */
  getTrafficTrendData(from: number, to: number, ticks: number, trafficType: string) {
    const url = `${environment.compassApiBaseUrl}/netviz/bandwidth/trafficTrend?trafficDir=${trafficType}&ticks=${ticks}`;
    return this.http.post(url, {from: from, to: to});
  }


  /**
   * @param primaryRange
   * @param secondaryRange
   * @returns {Observable<Object>}
   */
  getTopHostsChangeData(primaryRange, secondaryRange) {
    const url = `${environment.compassApiBaseUrl}/netviz/hosts/hostActivity`;
    return this.http.post<List<Host>>(url, {primaryRange, secondaryRange});
  }

  /**
   * @param {number} from
   * @param {number} to
   * @returns {Observable<Object>}
   */
  getAppActivityData(from: number, to: number) {
    const url = `${environment.compassApiBaseUrl}/netviz/application/usage`;
    return this.http.post(url, {from: from, to: to});
  }

  /**
   * @param {number} from
   * @param {number} to
   * @returns {Observable<Object>}
   */
  getProtocolsActivityData(from: number, to: number) {
    const url = `${environment.compassApiBaseUrl}/netviz/protocol/usage`;
    return this.http.post(url, {from: from, to: to});
  }
}
