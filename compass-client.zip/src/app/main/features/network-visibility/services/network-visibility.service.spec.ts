import { TestBed, inject } from '@angular/core/testing';

import { NetworkVisibilityService } from './network-visibility.service';

describe('NetworkVisibilityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NetworkVisibilityService]
    });
  });

  it('should be created', inject([NetworkVisibilityService], (service: NetworkVisibilityService) => {
    expect(service).toBeTruthy();
  }));
});
