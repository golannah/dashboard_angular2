import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {NetworkVisibilityComponent} from './components/network-visibility.component';
import {routing} from './network-visibility.routes';
import {TrafficTrendComponent} from './components/traffic-trend/traffic-trend.component';
import {ApplicationActivityComponent} from './components/application-activity/application-activity.component';
import {ProtocolsActivityComponent} from './components/protocols-activity/protocols-activity.component';
import {HostActivityComponent} from './components/host-activity/host-activity.component';
import {SharedModule} from '../../../shared/shared.module';
import {Daterangepicker} from 'ng2-daterangepicker';
import {HostActivityItemComponent} from './components/host-activity/host-activity-item/host-activity-item.component';
import {TranslateModule} from '@ngx-translate/core';
import {ProtocolsActivityModalComponent} from './components/protocols-activity/protocols-activity-modal/protocols-activity-modal.component';
import {ApplicationActivityModalComponent} from './components/application-activity/application-activity-modal/application-activity-modal.component';
import {HostActivityModalComponent} from './components/host-activity/host-activity-modal/host-activity-modal.component';
import {NgxChartsModule} from '@swimlane/ngx-charts';
import {NetworkVisibilityService} from './services/network-visibility.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    NgxChartsModule,
    TranslateModule,
    Daterangepicker,
    routing
  ],
  declarations: [
    NetworkVisibilityComponent,
    TrafficTrendComponent,
    ApplicationActivityComponent,
    ProtocolsActivityComponent,
    HostActivityComponent,
    HostActivityItemComponent,
    ProtocolsActivityModalComponent,
    ApplicationActivityModalComponent,
    HostActivityModalComponent
  ],
  entryComponents: [ProtocolsActivityModalComponent, ApplicationActivityModalComponent, HostActivityModalComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [NetworkVisibilityService]
})
export class NetworkVisibilityModule {
}
