export abstract class ProtocolsActivityBase {
  public name: string;
  public count: number;
}
