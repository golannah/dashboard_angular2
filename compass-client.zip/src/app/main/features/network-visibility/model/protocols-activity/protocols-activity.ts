import {ProtocolsActivityBase} from './protocols-activity.base';

export class ProtocolsActivity extends ProtocolsActivityBase {
}
