import {HostBase} from './host.base';

export class Host extends HostBase {
}
