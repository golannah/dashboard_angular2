export abstract class HostBase {
  public name: string;
  public increaseRate: number;
  public lastSevenDaysAverage: number;
  public todayAverage: number;
}
