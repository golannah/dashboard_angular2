import {AppActivityBase} from './app-activity.base';

export class AppActivity extends AppActivityBase {
}
