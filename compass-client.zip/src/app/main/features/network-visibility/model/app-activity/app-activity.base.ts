export abstract class AppActivityBase {
  public name: string;
  public count: number;
}
