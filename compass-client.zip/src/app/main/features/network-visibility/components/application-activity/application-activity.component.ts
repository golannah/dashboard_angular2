import {Component, Injector, Input, OnInit} from '@angular/core';
import {ApplicationActivityModalComponent} from './application-activity-modal/application-activity-modal.component';
import {BsModalRef, BsModalService} from 'ngx-bootstrap';
import {NetworkVisibilityService} from '../../services/network-visibility.service';

/**
 *  This component represent the activity of hosts in the site
 */
@Component({
  selector: 'app-application-activity',
  templateUrl: './application-activity.component.html',
  styleUrls: ['./application-activity.component.scss']
})

/**
 * This class represents the applications activity in the site, & visualize it via table.
 */
export class ApplicationActivityComponent implements OnInit {

  private modalService: BsModalService;
  private appActivityModalData: any[];
  private bsModalRef: BsModalRef;

  public referrerFooterText: string;
  public appActivityData: any[];

  /**
   * @param {Injector} injector
   * @param {NetworkVisibilityService} networkVisibilityService
   */
  constructor(private injector: Injector, private networkVisibilityService: NetworkVisibilityService) {
  }


  /**
   * This method return a reference to a modal service.
   * The service can render components into the bsModalRef that passed via show() function.
   * @returns {BsModalService} - the reference to the modal service.
   */
  private get modal(): BsModalService {
    if (!this.modalService) {
      this.modalService = this.injector.get(BsModalService);
    }
    return this.modalService;
  }

  /**
   * This function shoe the application-activity-modal, and inject relevant data into it.
   */
  openApplicationModal() {
    this.bsModalRef = this.modal.show(ApplicationActivityModalComponent);
    this.bsModalRef.content.title = 'Application Activity';
    this.bsModalRef.content.appActivityModalData = this.appActivityModalData;
  }

  getData(from, to) {
    this.networkVisibilityService.getAppActivityData(from, to)
      .subscribe(
        (data) => {
          this.appActivityData = Object.assign([], data['apps']);
          this.appActivityModalData = Object.assign([], data['apps']);

          this.appActivityData.splice(5, this.appActivityData.length);

        },
        err => console.log(err)
      );
  }

  ngOnInit() {
    this.referrerFooterText = 'See All Applications >>';
  }

}
