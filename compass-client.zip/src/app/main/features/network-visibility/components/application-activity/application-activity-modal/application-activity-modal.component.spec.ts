import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationActivityModalComponent } from './application-activity-modal.component';

describe('ApplicationActivityModalComponent', () => {
  let component: ApplicationActivityModalComponent;
  let fixture: ComponentFixture<ApplicationActivityModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationActivityModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationActivityModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
