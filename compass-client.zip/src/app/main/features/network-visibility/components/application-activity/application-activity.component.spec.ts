import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationActivityComponent } from './application-activity.component';

describe('ApplicationActivityComponent', () => {
  let component: ApplicationActivityComponent;
  let fixture: ComponentFixture<ApplicationActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
