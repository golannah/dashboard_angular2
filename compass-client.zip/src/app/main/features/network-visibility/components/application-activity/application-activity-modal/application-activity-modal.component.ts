import {Component, Injector, OnInit} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';

@Component({
  selector: 'app-application-activity-modal',
  templateUrl: './application-activity-modal.component.html',
  styleUrls: ['./application-activity-modal.component.scss']
})

/**
 * This class represents a modal component that view the extended data of the application activity in the site.
 */
export class ApplicationActivityModalComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public appActivityModalData: any[];
  public title: string;


  /**
   * @param {Injector} injector - the injector instance that gets the injected BsModalRef.
   */
  constructor(private injector: Injector) {
    this.bsModalRef = this.injector.get(BsModalRef);
  }


  ngOnInit() {
  }

}
