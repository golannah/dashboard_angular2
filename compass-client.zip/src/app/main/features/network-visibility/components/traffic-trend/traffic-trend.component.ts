import {Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {NetworkVisibilityService} from '../../services/network-visibility.service';
import * as moment from 'moment';
import {map, pick, mapKeys, mapValues, forEach} from 'lodash';

@Component({
  selector: 'app-traffic-trend',
  templateUrl: './traffic-trend.component.html',
  styleUrls: ['./traffic-trend.component.scss']
})

/**
 * This component represents the traffic trend of the site.
 */
export class TrafficTrendComponent implements OnInit {

  @ViewChild('trafficTrendWrap')
  private trafficTrendWrapRef: ElementRef;

  @Input() dateRange;
  @Input() trafficType;

  public trendData = [
    {
      'name': '',
      'series': []
    }
  ];
  public view: any[];
  public showXAxis = true;
  public showYAxis = true;
  public autoScale = true;
  public colorScheme = {
    all: {
      domain: ['#4bbbfc']
    },
    ingress: {
      domain: ['#4bbbfc']
    },
    egress: {
      domain: ['#c99bfd']
    }
  };

  constructor(private networkVisibilityService: NetworkVisibilityService) {
  }

  getData(from, to) {

    this.networkVisibilityService.getTrafficTrendData(from, to, 4, this.trafficType)
      .subscribe(
        (data) => {
          const trafficSeries = [];
          forEach(data['trafficPerInterval'], item => {
            trafficSeries.push(
              {name: moment(item['dateTime']).format('DD/MM, hh:mm'), value: item['value']}
            );
          });

          this.trendData = [];
          this.trendData.push({
            name: this.trafficType,
            series: trafficSeries
          });

        },
        err => console.log(err)
      );
  }

  ngOnInit() {
    setTimeout(() => {
      this.view = [
        this.trafficTrendWrapRef.nativeElement['clientWidth'] - 30,
        250
      ];
    });

  }

}
