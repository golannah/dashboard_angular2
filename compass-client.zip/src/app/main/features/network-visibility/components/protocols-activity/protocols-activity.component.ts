import {Component, Injector, Input, OnInit} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap';
import {ProtocolsActivityModalComponent} from './protocols-activity-modal/protocols-activity-modal.component';
import {NetworkVisibilityService} from '../../services/network-visibility.service';

@Component({
  selector: 'app-protocols-activity',
  templateUrl: './protocols-activity.component.html',
  styleUrls: ['./protocols-activity.component.scss']
})

/**
 * This class represents a component that view the activity of the protocols in the site.
 */
export class ProtocolsActivityComponent implements OnInit {

  @Input() protocolsActivityData: any[];

  private modalService: BsModalService;
  private bsModalRef: BsModalRef;
  private protocolsActivityModalData: any[];
  public referrerFooterText: string;


  /**
   * @param {Injector} injector - the injector instance that gets the injected BsModalRef.
   * @param {NetworkVisibilityService} networkVisibilityService
   */
  constructor(private injector: Injector, private networkVisibilityService: NetworkVisibilityService) {
  }

  /**
   * This method return a reference to a modal service.
   * The service can render components into the bsModalRef that passed via show() function.
   * @returns {BsModalService} - the reference to the modal service.
   */
  private get modal(): BsModalService {
    if (!this.modalService) {
      this.modalService = this.injector.get(BsModalService);
    }
    return this.modalService;
  }

  /**
   * This method opens the protocols activity modal
   */
  openProtocolsModal() {
    this.bsModalRef = this.modal.show(ProtocolsActivityModalComponent);
    this.bsModalRef.content.title = 'Protocols Activity';
    this.bsModalRef.content.protocolsActivityModalData = this.protocolsActivityModalData;
  }

  getData(from, to) {

    this.networkVisibilityService.getProtocolsActivityData(from, to)
      .subscribe(
        (data) => {
          this.protocolsActivityData = Object.assign([], data['protocols']);
          this.protocolsActivityModalData = Object.assign([], data['protocols']);

          this.protocolsActivityData.splice(5, this.protocolsActivityData.length);
        },
        err => console.log(err)
      );
  }

  ngOnInit() {
  this.referrerFooterText = 'See All Protocols >>';
  }

}
