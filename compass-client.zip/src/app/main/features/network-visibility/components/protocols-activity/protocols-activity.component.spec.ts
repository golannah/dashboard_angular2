import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProtocolsActivityComponent } from './protocols-activity.component';

describe('ProtocolsActivityComponent', () => {
  let component: ProtocolsActivityComponent;
  let fixture: ComponentFixture<ProtocolsActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProtocolsActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProtocolsActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
