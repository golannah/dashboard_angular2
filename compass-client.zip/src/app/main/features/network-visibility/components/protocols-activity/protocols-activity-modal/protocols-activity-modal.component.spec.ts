import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProtocolsActivityModalComponent } from './protocols-activity-modal.component';

describe('ProtocolsActivityModalComponent', () => {
  let component: ProtocolsActivityModalComponent;
  let fixture: ComponentFixture<ProtocolsActivityModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProtocolsActivityModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProtocolsActivityModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
