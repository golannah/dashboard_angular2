import {Component, Injector, OnInit} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';

@Component({
  selector: 'app-protocols-activity-modal',
  templateUrl: './protocols-activity-modal.component.html',
  styleUrls: ['./protocols-activity-modal.component.scss']
})

/**
 * This class represents a modal component that view the extended data of the protocols activity in the site.
 */
export class ProtocolsActivityModalComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public protocolsActivityModalData: any[];
  public title: string;

  /**
   * @param {Injector} injector - the injector instance that gets the injected BsModalRef.
   */
  constructor(private injector: Injector) {
    this.bsModalRef = this.injector.get(BsModalRef);
  }


  ngOnInit() {
  }

}
