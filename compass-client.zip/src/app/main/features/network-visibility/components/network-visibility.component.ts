import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {isNull} from 'util';
import {Ranges} from '../../dashboard/enums/date-range.enum';
import {LocalStorageService} from 'ngx-webstorage';
import {DateRange} from '../../dashboard/model/date-range';
import {RangeList} from '../../dashboard/model/range-list';
import {HostActivityComponent} from './host-activity/host-activity.component';
import {TrafficTrendComponent} from './traffic-trend/traffic-trend.component';
import * as moment from 'moment';
import {DynamicStylesService} from '../../../../core/services/dynamic-styles/dynamic-styles.service';
import {AppConstants} from '../../../../shared/constants/app-constants';
import {ApplicationActivityComponent} from './application-activity/application-activity.component';
import {NetworkVisibilityService} from '../services/network-visibility.service';
import {ProtocolsActivityComponent} from './protocols-activity/protocols-activity.component';


@Component({
  selector: 'app-network-visibility',
  templateUrl: './network-visibility.component.html',
  styleUrls: ['./network-visibility.component.scss']
})

/**
 * This class represents network visibility component, that wrap all its widget components.
 */
export class NetworkVisibilityComponent implements OnInit, AfterViewInit {

  @ViewChild('hostActivity') hostActivityCmp: HostActivityComponent;
  @ViewChild('protocolsActivity') protocolsActivityCmp: ProtocolsActivityComponent;
  @ViewChild('trafficTrendIngress') trafficTrendIngressCmp: TrafficTrendComponent;
  @ViewChild('trafficTrendEgress') trafficTrendEgressCmp: TrafficTrendComponent;
  @ViewChild('trafficTrendAll') trafficTrendAllCmp: TrafficTrendComponent;

  public protocolsActivityData = [
    {name: 'HTTPS', count: 2},
    {name: 'SHH', count: 11},
    {name: 'HTTP', count: 5},
    {name: 'Lorem', count: 5},
    {name: 'Ipsum', count: 1}
  ];
  public dateRange: DateRange;
  public hostsFirstDateRange: DateRange;
  public hostsSecondDateRange: DateRange;
  // private dateRangeOptions: DateRangeOptions;
  public hostsFirstDateRangeOptions;
  public hostsSecondDateRangeOptions;
  private rangeList: RangeList;
  public isAllTraffic = true;

  /**
   *
   * @param {LocalStorageService} localSt
   * @param {DynamicStylesService} dynamicStylesService
   */
  constructor(private localSt: LocalStorageService, private dynamicStylesService: DynamicStylesService) {

  }


  initDateRangePicker() {
    this.rangeList = {
      'Yesterday': <any>[Ranges.YesterdayStart, Ranges.TodayEnd],
      'Last 3 Days': <any>[Ranges.Last3Days, Ranges.TodayEnd],
      'Last 7 Days': <any>[Ranges.Last7Days, Ranges.TodayEnd],
      'Last Month': <any>[Ranges.LastMonth, Ranges.TodayEnd],
    };

    if (isNull(this.localSt.retrieve('networkVisibilityTimeRange'))) {
      this.dateRange = {
        startDate: Ranges.Last7Days,
        endDate: Ranges.TodayEnd,
        label: 'Last 7 days'
      };
      this.localSt.store('networkVisibilityTimeRange', this.dateRange);
    } else {
      this.dateRange = {
        startDate: this.localSt.retrieve('networkVisibilityTimeRange').startDate,
        endDate: this.localSt.retrieve('networkVisibilityTimeRange').endDate,
        label: this.localSt.retrieve('networkVisibilityTimeRange').label
      };
    }

    if (isNull(this.localSt.retrieve('networkVisibilityHostsTimeRange'))) {
      this.hostsFirstDateRange = {
        startDate: Ranges.TodayStart,
        endDate: Ranges.TodayEnd,
        label: 'Yesterday'
      };
      this.hostsSecondDateRange = {
        startDate: Ranges.YesterdayStart,
        endDate: Ranges.YesterdayEnd,
        label: 'Yesterday'
      };
      this.localSt.store('networkVisibilityHostsTimeRange', {
        first: this.hostsFirstDateRange,
        second: this.hostsSecondDateRange
      });
    } else {
      this.hostsFirstDateRange = {
        startDate: this.localSt.retrieve('networkVisibilityHostsTimeRange').first.startDate,
        endDate: this.localSt.retrieve('networkVisibilityHostsTimeRange').first.endDate,
        label: this.localSt.retrieve('networkVisibilityHostsTimeRange').first.label
      };
      this.hostsSecondDateRange = {
        startDate: this.localSt.retrieve('networkVisibilityHostsTimeRange').second.startDate,
        endDate: this.localSt.retrieve('networkVisibilityHostsTimeRange').second.endDate,
        label: this.localSt.retrieve('networkVisibilityHostsTimeRange').second.label
      };
    }

    this.hostsFirstDateRangeOptions = {
      locale: {format: 'YYYY-MM-DD'},
      alwaysShowCalendars: true,
      startDate: Ranges.TodayStart,
      endDate: Ranges.TodayEnd,
      ranges: {
        'Today': [Ranges.TodayEnd, Ranges.TodayEnd],
        'Yesterday': [Ranges.YesterdayStart, Ranges.TodayEnd],
        'Last 3 Days': [Ranges.Last3Days, Ranges.TodayEnd],
        'Last 7 Days': [Ranges.Last7Days, Ranges.TodayEnd],
        'Last Month': [Ranges.LastMonth, Ranges.TodayEnd],
      },
      opens: 'left'
    };
    this.hostsSecondDateRangeOptions = {
      locale: {format: 'YYYY-MM-DD'},
      alwaysShowCalendars: true,
      startDate: Ranges.YesterdayStart,
      endDate: Ranges.YesterdayEnd,
      ranges: {
        'Today': [Ranges.TodayEnd, Ranges.TodayEnd],
        'Yesterday': [Ranges.YesterdayStart, Ranges.TodayEnd],
        'Last 3 Days': [Ranges.Last3Days, Ranges.TodayEnd],
        'Last 7 Days': [Ranges.Last7Days, Ranges.TodayEnd],
        'Last Month': [Ranges.LastMonth, Ranges.TodayEnd],
      },
      opens: 'left'
    };
  }


  /**
   * This method gets a selected time range from the date range picker, and
   *
   * @param dateRange - the event object that returned from the date-range-picker component.
   */
  onDateRangeSelected(dateRange: any) {
    this.dateRange = {
      startDate: moment(dateRange.start).valueOf(),
      endDate: moment(dateRange.end).valueOf(),
      label: dateRange.label
    };
    this.getAllWidgetsData();
  }

  /**
   * This method gets a selected time range from the date range picker, and
   *
   * @param hostsFirstDateRange - the event object that returned from the date-range-picker component.
   */
  onHostsFirstDateRangeSelected(hostsFirstDateRange: any) {
    this.hostsFirstDateRange = {
      startDate: moment(hostsFirstDateRange.start).valueOf(),
      endDate: moment(hostsFirstDateRange.end).valueOf(),
      label: hostsFirstDateRange.label
    };
    this.getHostActivityData();
  }

  /**
   * This method gets a selected time range from the date range picker, and
   *
   * @param hostsSecondDateRange - the event object that returned from the date-range-picker component.
   */
  onHostsSecondDateRangeSelected(hostsSecondDateRange: any) {
    this.hostsSecondDateRange = {
      startDate: moment(hostsSecondDateRange.start).valueOf(),
      endDate: moment(hostsSecondDateRange.end).valueOf(),
      label: hostsSecondDateRange.label
    };
    this.getHostActivityData();
  }

  getHostActivityData() {
    const primaryFrom = moment(this.hostsFirstDateRange.startDate).valueOf();
    const primaryTo = moment(this.hostsFirstDateRange.endDate).valueOf();
    const secondaryFrom = moment(this.hostsSecondDateRange.startDate).valueOf();
    const secondaryTo = moment(this.hostsSecondDateRange.endDate).valueOf();

    let primaryRange = {
      from: primaryFrom,
      to: primaryTo
    };

    let secondaryRange = {
      from: secondaryFrom,
      to: secondaryTo
    };

    const isSecondaryRangeLaterThanPrimary = secondaryRange.from > primaryRange.to;

    if (isSecondaryRangeLaterThanPrimary) {
      [primaryRange, secondaryRange] = [secondaryRange, primaryRange];
    }

    this.hostActivityCmp.getData(primaryRange, secondaryRange, isSecondaryRangeLaterThanPrimary);
  }

  getAllWidgetsData() {
    const from = moment(this.dateRange.startDate).valueOf();
    const to = moment(this.dateRange.endDate).valueOf();

    if (this.isAllTraffic) {
      this.trafficTrendAllCmp.getData(from, to);
    }

    else {
      this.trafficTrendIngressCmp.getData(from, to);
      this.trafficTrendEgressCmp.getData(from, to);
    }

    this.protocolsActivityCmp.getData(from, to);

  }

  ngOnInit() {
    this.initDateRangePicker();

    setTimeout(() => {
      // this.dynamicStylesService.setDynamicStyles();
    }, 3000);

  }

  ngAfterViewInit() {
    this.getHostActivityData();
    this.getAllWidgetsData();

    /*setInterval(() => {
      this.getHostActivityData();
      this.getAllWidgetsData();
    }, AppConstants.POLLING_INTERVAL);*/
  }

}
