import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostActivityModalComponent } from './host-activity-modal.component';

describe('HostActivityModalComponent', () => {
  let component: HostActivityModalComponent;
  let fixture: ComponentFixture<HostActivityModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostActivityModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostActivityModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
