import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostActivityComponent } from './host-activity.component';

describe('HostActivityComponent', () => {
  let component: HostActivityComponent;
  let fixture: ComponentFixture<HostActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
