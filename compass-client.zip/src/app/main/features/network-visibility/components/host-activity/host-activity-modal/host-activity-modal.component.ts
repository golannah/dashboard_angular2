import {Component, Injector, OnInit, ViewChild} from '@angular/core';
import {Host} from '../../../model/host/host';
import {List} from '../../../../../../core/model/list';
import {BsModalRef} from 'ngx-bootstrap';
import {HostActivityComponent} from '../host-activity.component';

@Component({
  selector: 'app-host-activity-modal',
  templateUrl: './host-activity-modal.component.html',
  styleUrls: ['./host-activity-modal.component.scss']
})

/**
 * This class represents a modal component that view the extended data of the host activity in the site.
 */
export class HostActivityModalComponent implements OnInit {
  @ViewChild('hostActivityModal') hostActivityModalRef;

  public bsModalRef: BsModalRef;
  public title: string;
  public totalText: string;
  public hostsList;
  public controlsConfigObj;

  /**
   * @param {Injector} injector - the injector instance that gets the injected BsModalRef.
   */
  constructor(private injector: Injector) {
    this.bsModalRef = this.injector.get(BsModalRef);
  }

  ngOnInit() {
    setTimeout(() => {
      this.hostActivityModalRef.nativeElement.parentElement.parentElement.className += ' host-activity-modal';
      this.totalText = `Total of ${this.hostsList.length} Hosts`;
      this.controlsConfigObj = {
        search: true, filter: false, download: false, toggleView: false
      };
    }, 0);
  }


}
