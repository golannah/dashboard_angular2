import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostActivityItemComponent } from './host-activity-item.component';

describe('HostActivityItemComponent', () => {
  let component: HostActivityItemComponent;
  let fixture: ComponentFixture<HostActivityItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostActivityItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostActivityItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
