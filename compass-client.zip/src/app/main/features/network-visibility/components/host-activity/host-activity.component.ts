import {Component, Injector, Input, OnInit} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap';
import {HostActivityModalComponent} from './host-activity-modal/host-activity-modal.component';
import {Host} from '../../model/host/host';
import {List} from '../../../../../core/model/list';
import {NetworkVisibilityService} from '../../services/network-visibility.service';
import {forEach, map, extend} from 'lodash';
import * as moment from 'moment';


@Component({
  selector: 'app-host-activity',
  templateUrl: './host-activity.component.html',
  styleUrls: ['./host-activity.component.scss']
})

/**
 * This class represents a component that view the activity of the hosts in the site.
 */
export class HostActivityComponent implements OnInit {

  @Input() firstDateRange;
  @Input() secondDateRange;

  private modalService: BsModalService;
  private bsModalRef: BsModalRef;

  public referrerFooterText: string;

  // Todo: define the response as List<Host> (but we need to understand what to do with other response properties
  public hostsList;
  public modalHostsList;

  /**
   * @param {Injector} injector - the injector instance that gets the injected BsModalRef.
   * @param {NetworkVisibilityService} networkVisibilityService
   */
  constructor(private injector: Injector, private networkVisibilityService: NetworkVisibilityService) {
  }

  /**
   * This method return a reference to a modal service.
   * The service can render components into the bsModalRef that passed via show() function.
   * @returns {BsModalService} - the reference to the modal service.
   */
  private get modal(): BsModalService {
    if (!this.modalService) {
      this.modalService = this.injector.get(BsModalService);
    }
    return this.modalService;
  }


  /**
   * This method opens the host activity modal
   */
  openHostsModal() {
    this.bsModalRef = this.modal.show(HostActivityModalComponent);
    this.bsModalRef.content.title = 'Host Activity';
    this.bsModalRef.content.hostsList = this.modalHostsList;
  }

  getData(primaryRange, secondaryRange, swapRanges) {

    this.networkVisibilityService.getTopHostsChangeData(primaryRange, secondaryRange)
      .subscribe(
        (data) => {

          this.hostsList = map(data['hostsActivity'], (element) => {
            return extend({}, element, {
              firstDateRangeLabel: this.firstDateRange.label,
              secondDateRangeLabel: this.secondDateRange.label
            });
          });

          if (swapRanges) {
            this.hostsList = this.swapAverages(data['hostsActivity']);
          }

          this.modalHostsList = Object.assign([], this.hostsList);
          this.hostsList.splice(5, this.hostsList.length);

        },
        err => console.log(err)
      );
  }

  swapAverages(hostsData) {
    forEach(hostsData, item => {
      [item['newAvg'], item['oldAvg']] = [item['oldAvg'], item['newAvg']];
    });
    return hostsData;
  }

  ngOnInit() {
    this.referrerFooterText = 'See All Hosts >>';
  }

}


