import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-host-activity-item',
  templateUrl: './host-activity-item.component.html',
  styleUrls: ['./host-activity-item.component.scss']
})
/**
 * This class represents a component of a single host item, that view it state through today & last 7 days.
 */
export class HostActivityItemComponent implements OnInit {

  @Input() hostData;
  Math: any;
  increasing: boolean;

  constructor() {
    this.Math = Math;
  }


  ngOnInit() {
   this.increasing =  this.hostData.percentChange > 0;
  }

}
