import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NetworkVisibilityComponent } from './network-visibility.component';

describe('NetworkVisibilityComponent', () => {
  let component: NetworkVisibilityComponent;
  let fixture: ComponentFixture<NetworkVisibilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NetworkVisibilityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NetworkVisibilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
