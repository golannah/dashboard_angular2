/**
 * Class representing the Threat State Info
 */
export class EventStateInfo {
  public changeStateBy: string;
  public closingReason: number;
  public note: string;
  public state: string;
  public timestamp: string;
}
