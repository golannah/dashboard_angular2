import {EventMetadataDto} from './event-metadata-dto';

/**
 * Class representing the base for every type of threat data
 */
export class EventBase {
  constructor() {
    this.threatMetadataDTO = new EventMetadataDto();
  }
  public id: number;
  public assetIp: string;
  public startTimestamp: number;
  public endTimestamp: number;
  public name: string;
  public risk: number;
  public assignedTo: string;
  public closedBy: string;
  public closingReason: string;
  public closingTimestamp: number;
  threatMetadataDTO: EventMetadataDto;
  eventCount: number;
}

