import {EventBase} from './event.base';
import {List} from '../../../../core/model/list';
export class EventList extends List<EventBase> {
  public content: EventBase[];
  constructor() {
    super();
  }
}
