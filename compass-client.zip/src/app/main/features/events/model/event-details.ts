export class EventDetails {
}
