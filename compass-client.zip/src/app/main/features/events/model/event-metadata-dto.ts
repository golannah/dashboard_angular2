import {EventAssignInfo} from './event-assign-info';
import {EventStateInfo} from './event-state-info';

/**
 * Data Transfer Object for Event MetaData
 */
export class EventMetadataDto {
  public assignInfo: EventAssignInfo;
  public stateInfo: EventStateInfo;

}
