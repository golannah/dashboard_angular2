export class EventFilter {
  public startTimestmp: number;
  public endTimestamp: number;
  public name: string;
  public risk: number;
  public assigned_to: string;
  public state: string;
  public showFalseAlarms: boolean;
  public showNotIteresting: boolean;
}
