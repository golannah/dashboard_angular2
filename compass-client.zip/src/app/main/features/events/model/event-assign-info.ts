/**
 * Details of Threat assignment
 */
export class EventAssignInfo {
  assignTimestamp: string;
  assignedUser: string;
  note: string;
}
