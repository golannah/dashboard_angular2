export class EventNote {
  public  note: string;
}
