import {Component, Injector, OnInit, ViewChild} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';
import {EventBase} from '../../model/event.base';
import {EventsService} from '../../services/events.service';
import {User} from '../../../users/model/user';
import {EventNote} from '../../model/event-note';
import {AddNoteComponent} from '../../../../../shared/components/add-note/add-note.component';
import {UsersTypeaheadComponent} from '../../../users/components/users-typeahead/users-typeahead.component';
import {SelectItem} from 'primeng/primeng';

@Component({
  selector: 'app-event-threat',
  templateUrl: './assign-event.component.html',
  styleUrls: ['./assign-event.component.scss']
})
export class AssignEventComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public threat: EventBase;
  public users: SelectItem [];
  public note: EventNote = new EventNote();
  @ViewChild(AddNoteComponent) noteComponent: AddNoteComponent;
  @ViewChild(UsersTypeaheadComponent) userComponent: UsersTypeaheadComponent;
  constructor(private injector: Injector, private threatService: EventsService) {
    this.bsModalRef = this.injector.get(BsModalRef);
  }
  public appyClicked() {
    this.note.note = this.noteComponent.getNote();
    this.users = this.userComponent.getSelectedUsers();
    /*this.assignThreat(this.user, this.threat, this.note);*/
  }
  /*public assignThreat(user: any, threat: EventBase, note: EventNote) {
    this.threatService.assignThreat(user, threat, note).subscribe(data => {
      this.bsModalRef.hide();
    });
  }*/

  ngOnInit() {
  }

}
