import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreatsFilterComponent } from './threats-filter.component';

describe('ThreatsFilterComponent', () => {
  let component: ThreatsFilterComponent;
  let fixture: ComponentFixture<ThreatsFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreatsFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreatsFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
