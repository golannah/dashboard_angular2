import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events-filter',
  templateUrl: './events-filter.component.html',
  styleUrls: ['./events-filter.component.scss']
})
export class EventsFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
