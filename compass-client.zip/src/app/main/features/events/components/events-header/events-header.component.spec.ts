import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreatsHeaderComponent } from './threats-header.component';

describe('ThreatsHeaderComponent', () => {
  let component: ThreatsHeaderComponent;
  let fixture: ComponentFixture<ThreatsHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreatsHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreatsHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
