import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events-header',
  templateUrl: './events-header.component.html',
  styleUrls: ['./events-header.component.scss']
})
export class EventsHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
