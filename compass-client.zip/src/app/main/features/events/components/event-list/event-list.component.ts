import {Component, OnInit} from '@angular/core';
import {EventList} from '../../model/events-list';
import {EventsService} from '../../services/events.service';
import {LoggerService} from '../../../../../core/services/logging/logger.service';
import {get} from 'lodash';
import {EventFilter} from '../../model/event-filter';


@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.scss']
})
export class EventListComponent implements OnInit {
  public eventList: EventList = new EventList();
  public totalText: string;
  public filterOptions: EventFilter = new EventFilter();
  public isFilterOpen = false;

  constructor(private eventService: EventsService,
              private logger: LoggerService) {
    this.filterOptions.risk = 10;
  }

  ngOnInit() {

    this.eventService.getThreats().subscribe(data => {
      this.eventList  = data;
      this.totalText = `Total of ${this.eventList.totalElements}`;
    });
  }



  filterApply() {
  }

  filterResetToDefault() {
  }

  /**
   * Calback for trigger threat callback
   * @param isFilterOpen - boolean
   */
  showFilter(isFilterOpen: boolean) {
    this.isFilterOpen = isFilterOpen;
  }

  /**
   * Callback for search threats
   * @param {event} - event from search
   */
  searchThreats(event) {
    const query: string = get(event, 'data');
    this.logger.log('Search query is:', query);
  }

  shareThreatData() {
  }

}
