import {Component, Input, OnInit} from '@angular/core';
import {get} from 'lodash';
import {Menu, MenuItem} from 'primeng/primeng';
import {EventBase} from '../../../model/event.base';
import {ModalComponent} from '../../../../../../shared/components/modal-component/modal-component.component';
import {BsModalRef, BsModalService} from 'ngx-bootstrap';
import {Router} from '@angular/router';

@Component({
  selector: 'app-event-list-table',
  templateUrl: './list-table.component.html',
  styleUrls: ['./list-table.component.scss']
})
export class EventListTableComponent implements OnInit {

  @Input() eventList;
  items: MenuItem[];
  shareDataModal: BsModalRef;

  constructor(private modalService: BsModalService,
              private router: Router) {

  }

  ngOnInit() {

    this.items = [{label: 'Report a threat'}];
  }




  /**
   * Callback for share threat data service
   */
  shareThreatData() { // TODO  : create modal for sharing data
    this.shareDataModal = this.modalService.show(ModalComponent);
    this.shareDataModal.content.title = 'Share threat data'
    ;
  }

  openMenu(events: EventBase, menu: Menu, event: any) {
    /* this.selectedThreat = events;*/
    menu.toggle(event);
    event.stopPropagation();
  }

  onRowSelect(tableRowSelected) {
    const eventId = get(tableRowSelected, 'data.id');
    this.router.navigate([`main/events/${eventId}`]);
  }

  /**
   * @param rowData -  ThreatBase object.
   * @returns {string}
   */
  getCategories(rowData) {
    // TODO  : get categories from categories service
    return 'Worm,Virus,DDos';
  }

  /**
   * @param rowData -  ThreatBase object.
   * @returns {string}
   */
  getPlugins(rowData) {
    // TODO : get plugins from plugin service
    return 'CheckPoint';

  }

}
