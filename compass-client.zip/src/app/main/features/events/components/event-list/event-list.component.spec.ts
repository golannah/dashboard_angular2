import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreatListComponent } from './threat-list.component';

describe('ThreatListComponent', () => {
  let component: ThreatListComponent;
  let fixture: ComponentFixture<ThreatListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreatListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreatListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
