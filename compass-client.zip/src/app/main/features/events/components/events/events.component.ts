import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import 'rxjs/add/operator/switchMap';
import {EventsService} from '../../services/events.service';
import * as moment from 'moment';
import {EventList} from '../../model/events-list';
import {Menu, MenuItem} from 'primeng/primeng';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss']
})
export class EventComponent implements OnInit {
  public eventList: EventList = new EventList();
  public eventRange: any;
  public totalText: string;
  items: MenuItem[];

  constructor(private route: ActivatedRoute,
              private router: Router,
              private eventService: EventsService) {
  }

  ngOnInit() {
    this.eventService.getThreats().subscribe(data => {
      setTimeout(() => {
        this.eventList = data;
      }, 0);
      this.totalText = `Total of ${this.eventList.totalElements}`;
    });

    this.eventRange = {
      firstEvent: moment(),
      lastEvent: moment().add(1, 'months')
    };

    this.items = [{label: 'Report a threat'}];
  }

  openMenu(menu: Menu, event: any) {

    menu.toggle(event);
    event.stopPropagation();
  }
  public onCategorySelected(category) {

    this.router.navigate(['main/events'], { queryParams: { category: category.name } });
  }

}
