import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloseThreatComponent } from './close-threat.component';

describe('CloseThreatComponent', () => {
  let component: CloseThreatComponent;
  let fixture: ComponentFixture<CloseThreatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloseThreatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloseThreatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
