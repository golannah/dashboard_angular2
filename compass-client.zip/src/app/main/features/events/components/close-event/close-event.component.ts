import {Component, Injector, OnInit, ViewChild} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';
import {EventBase} from '../../model/event.base';
import {User} from '../../../users/model/user';
import {EventNote} from '../../model/event-note';
import {EventsService} from '../../services/events.service';
import {EventClosingReason} from '../../enums/event-closing-reason.enum';
import {EventStateInfo} from '../../model/event-state-info';
import {AddNoteComponent} from '../../../../../shared/components/add-note/add-note.component';
import {UsersService} from '../../../users/users.service';
import {SelectItem} from 'primeng/primeng';

@Component({
  selector: 'app-close-event',
  templateUrl: './close-event.component.html',
  styleUrls: ['./close-event.component.scss']
})
export class CloseEventComponent implements OnInit {

  public bsModalRef: BsModalRef;
  public threat: EventBase;
  public currentUser: User;
  public note: EventNote = new EventNote();
  public closingReason: any = EventClosingReason.NOT_NANDLED;
  @ViewChild(AddNoteComponent) noteComponent: AddNoteComponent;
  public closingOptions: SelectItem [];
  constructor(private injector: Injector, private threatService: EventsService) {
    this.bsModalRef = this.injector.get(BsModalRef);
    this.currentUser = UsersService.getCurrentUser();
    this.closingOptions = this.buildOptions();
  }
  public appyClicked() {
    this.closeThreat(this.threat);
  }
  public closeThreat(event: EventBase) {
      const threatCloseInfo = new EventStateInfo();
      threatCloseInfo.closingReason = this.closingReason;
      threatCloseInfo.changeStateBy = this.currentUser.identifier;
      threatCloseInfo.note = this.noteComponent.getNote();
      /*this.threatService.closeThreat(threat.id, threatCloseInfo).subscribe(data => {
          this.bsModalRef.hide();
      });*/
  }

  buildOptions() {
    const selectItems: SelectItem [] = [];
    const notHandled = {label : 'Not Handled', value : EventClosingReason.NOT_NANDLED};
    const falsePoistive = {label : 'False Positive', value : EventClosingReason.FALSE_POSITIVE};
    const notInterested = {label : 'Not Interested', value : EventClosingReason.NOT_INTERESTING};
    selectItems.push(notHandled);
    selectItems.push(falsePoistive);
    selectItems.push(notInterested);
    return selectItems;
  }

  ngOnInit() {
  }

}
