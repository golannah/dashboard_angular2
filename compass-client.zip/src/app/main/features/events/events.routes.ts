
import { Route, RouterModule } from '@angular/router';

import {ModuleWithProviders} from '@angular/core';
import {EventComponent} from './components/events/events.component';
import {EventListComponent} from './components/event-list/event-list.component';

export const EventsRoutes: Route[] = [
  {
    path: 'events',
    component: EventListComponent
  },
  {
    path: 'events/:id',
    component: EventComponent
  }
];


export const routing: ModuleWithProviders = RouterModule.forChild(EventsRoutes);



