import {Injectable} from '@angular/core';
import {HttpClient, HttpEvent} from '@angular/common/http';
import {environment} from '../../../../../environments/environment';
import {EventFilter} from '../model/event-filter';
import {User} from '../../users/model/user';
import {EventBase} from '../model/event.base';
import {EventNote} from '../model/event-note';
import {EventList} from '../model/events-list';
import {EventDetails} from '../model/event-details';
import {EventStateInfo} from '../model/event-state-info';
@Injectable()
/**
 * Threats service responsible for basic operations on threats
 */
export class EventsService {
  constructor(private httpClient: HttpClient) {}
  private getFilterParams() {
    return {};
  }

  /**
   * Get avalibale threats - filter by user filter and paginated
   * @param {ThreatsFilter} filter
   * @param options - pagionation and date time parameters taken from url state
   * @returns {Observable<Object>}  - collection of ThreatList
   * */
  getThreats(filter?: EventFilter, options?: any) {
    const url = `${environment.compassApiBaseUrl}/events`;
    return this.httpClient.post<EventList>(url, filter);
  }

  /**
   * Get spesific threat summary details
   * @param {number} threatId
   */
  getThreatDetails(threatId: string) {
    const url = `${environment.compassApiBaseUrl}/events/${threatId}`;
    return this.httpClient.get<EventDetails>(url);
  }

  /**
   * Close threat and provide close details
   * @param {number} threatId
   * @param body
   * @returns {Observable<Object>}
   */
  closeThreat(threatId: number, eventStateInfo: EventStateInfo) {
    const url = `${environment.compassApiBaseUrl}/events/${threatId}/close`;
    return this.httpClient.put<any>(url, eventStateInfo);
  }

  /**
   * Get threat notes , optionally paginated
   * @param {number} threatId
   * @param options
   * @returns {Observable<Object>}
   */
  getThreatNotes(threatId: number, options?: any) {
    const url = `${environment.compassApiBaseUrl}/events/${threatId}/close`;
    return this.httpClient.get<any>(url);
  }

  /**
   * Add notes to threat
   * @param {number} threatId
   * @param {ThreatNote[]} notes
   * @returns {Observable<Object>}
   */
  addThreatNotes(threatId: number, notes: EventNote []) {
    const url = `${environment.compassApiBaseUrl}/events/${threatId}/addNotes`;
    return this.httpClient.put<any>(url, notes);
  }

  /**
   * Assign threat to spesific user
   * @param {User} user
   * @param {ThreatBase} threat
   * @param {ThreatNote} note
   * @returns {Observable<Object>}
   */
  assignThreat(user: User, event: EventBase, note: EventNote) {
    const url = `${environment.compassApiBaseUrl}/events/${event.id}/assign`;
    const body  = {
      assignedUserId: 'fff',
      note: note.note
    };
    return this.httpClient.put(url, body,);
  }

  /**
   * Free search of threats by query
   * @param {string} query
   * @returns {Observable<Object>}
   */
  search(query: string) {
    const url = `${environment.compassApiBaseUrl}/events/search/${query}`;
    return this.httpClient.get<EventList>(url);
  }
}
