import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ConfirmDialogModule, MenuModule, SliderModule} from 'primeng/primeng';
import {HttpClientModule} from '@angular/common/http';
import {CoreModule} from '../../../core/core.module';
import {SharedModule} from '../../../shared/shared.module';
import {EventListComponent} from './components/event-list/event-list.component';
import {EventsService} from './services/events.service';
import {routing} from './events.routes';
import {EventComponent} from './components/events/events.component';
import {AssignEventComponent} from './components/assign-event/assign-event.component';
import {EventsHeaderComponent} from './components/events-header/events-header.component';
import {CloseEventComponent} from './components/close-event/close-event.component';
import {UsersModule} from '../users/users.module';
import {FormsModule} from '@angular/forms';
import {EventListTableComponent} from './components/event-list/list-table/list-table.component';
import {EventsFilterComponent} from './components/events-filter/events-filter.component';


@NgModule({
  imports: [
    CoreModule,
    HttpClientModule,
    ConfirmDialogModule,
    CommonModule,
    routing,
    SharedModule,
    MenuModule,
    SliderModule,
    UsersModule,
    FormsModule
  ],
  declarations: [
    EventComponent,
    EventListComponent,
    AssignEventComponent,
    EventsHeaderComponent,
    CloseEventComponent,
    EventListTableComponent,
    EventsFilterComponent],
  providers: [EventsService],
  entryComponents: [AssignEventComponent, CloseEventComponent]
})
export class EventsModule {
}
