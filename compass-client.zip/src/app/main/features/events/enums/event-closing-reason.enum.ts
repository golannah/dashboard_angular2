export enum EventClosingReason {
  NOT_NANDLED =  1,
  FALSE_POSITIVE = 2,
  NOT_INTERESTING  = 3,
}
