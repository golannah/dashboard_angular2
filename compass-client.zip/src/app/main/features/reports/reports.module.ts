import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportListComponent } from './reports/report-list/report-list.component';
import {routing} from "./reports.routes";
import { ReportsComponent } from './reports/reports.component';

@NgModule({
  imports: [
    CommonModule,
    routing
  ],
  declarations: [ReportListComponent, ReportsComponent]
})
export class ReportsModule { }
