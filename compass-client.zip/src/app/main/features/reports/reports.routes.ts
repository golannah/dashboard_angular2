

import { Route, RouterModule } from '@angular/router';

import {ModuleWithProviders} from '@angular/core';
import {ReportsComponent} from './reports/reports.component';

export const ReportsRoutes: Route[] = [
  {
    path: 'reports',
    component: ReportsComponent
  }
];


export const routing: ModuleWithProviders = RouterModule.forChild(ReportsRoutes);

