import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {MainComponent} from './main.component';
import {AdminModule} from './features/admin/admin.module';
import {ThreatsModule} from './features/threats/threats.module';
import {ReportsModule} from './features/reports/reports.module';
import {NotificationsModule} from './features/notifications/notifications.module';
import {DashboardModule} from './features/dashboard/dashboard.module';
import {NotificationsRoutingModule} from './features/notifications/notificaitons-routing.module';
import {NetworkVisibilityModule} from './features/network-visibility/network-visibility.module';
import {SharedModule as AppSharedModule} from '../shared/shared.module';
import {MainRoutes} from './main.routes';
import {TopMenuComponent} from './components/top-menu/top-menu.component';
import {LeftMenuComponent} from './components/left-menu/left-menu.component';
import {CoreModule} from '../core/core.module';
import {AuthenticationModule} from '../authentication/authentication.module';
import {EventsModule} from './features/events/events.module';
import {RouteTitleComponent} from './components/top-menu/route-title/route-title.component';
import {CloseMenuService} from './components/left-menu/service/close-menu.service';

import {TranslateModule} from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    AppSharedModule,
    NotificationsRoutingModule,
    MainRoutes,
    DashboardModule,
    NotificationsModule,
    ReportsModule,
    ThreatsModule,
    AdminModule,
    NetworkVisibilityModule,
    AuthenticationModule,
    EventsModule,
    CoreModule,
    TranslateModule
  ],
  declarations: [
    MainComponent,
    TopMenuComponent,
    LeftMenuComponent,
    RouteTitleComponent
  ],
  providers: [
    CloseMenuService
  ],
})
export class MainModule { }
