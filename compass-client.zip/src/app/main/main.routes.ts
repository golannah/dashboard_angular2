import {Route, RouterModule} from '@angular/router';
import {MainComponent} from './main.component';
import {ModuleWithProviders} from '@angular/core';
import {DashboardRoutes} from './features/dashboard/dashboard.routes';
import {ThreatsRoutes} from './features/threats/threats.routes';
import {ReportsRoutes} from './features/reports/reports.routes';
import {NetworkVisibilityRoutes} from './features/network-visibility/network-visibility.routes';
import {AuthCanActivateGuard} from '../authentication/guard/AuthCanActivateGuard';
import {EventsRoutes} from './features/events/events.routes';
import {AdminRoutes} from './features/admin/admin.routes';

export const routes: Route[] = [
  {
    path: 'main',
    component: MainComponent,
    children: [...DashboardRoutes, ...ThreatsRoutes , ...ReportsRoutes, ...NetworkVisibilityRoutes, ...EventsRoutes, ...AdminRoutes ],
    canActivate: [AuthCanActivateGuard],
    canActivateChild : [AuthCanActivateGuard]
  }
];

export const MainRoutes: ModuleWithProviders = RouterModule.forChild(routes);
