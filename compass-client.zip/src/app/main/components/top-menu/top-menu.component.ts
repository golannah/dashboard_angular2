import {Component, OnInit,OnDestroy} from '@angular/core';
import {AuthenticationService} from '../../../authentication/authentication.service';
import {User} from '../../features/users/model/user';
import {UsersService} from '../../features/users/users.service';
import {Router} from '@angular/router';
import {LocalStorageService} from 'ngx-webstorage';
import {Subject} from 'rxjs/Subject';
import {CloseMenuService} from '../left-menu/service/close-menu.service';
import {Subscription} from 'rxjs/Subscription';

@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.scss']
})
export class TopMenuComponent implements OnInit,OnDestroy {

  public user: User;
  public userProfileMenuOpened = false;
  public menuOpen = false;
  public leftMenuStatus: Subject<any> = new Subject();
  public closeMenu: Subject<any> = new Subject();
  subscription: Subscription;

  constructor(private authService: AuthenticationService,
              private router: Router,
              private localStorageService: LocalStorageService,
              private closeMenuService: CloseMenuService) {

    this.subscription = this.closeMenuService.closeLeftMenu().subscribe(message => {

      this.menuOpen = false;
    });
  }

  ngOnInit() {
    this.user = UsersService.getCurrentUser();
  }

  logout() {
    this.authService.logout().subscribe((data) => {
      this.router.navigate(['/login']);
      this.localStorageService.clear('token');
    });
  }

  openMenu() {
    this.menuOpen = !this.menuOpen;
    if (!this.menuOpen) {
      // this.leftMenuStatus.next(true);
      this.closeMenuService.setHamburgerCloseIcon('close');
    }


  }
  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }
}
