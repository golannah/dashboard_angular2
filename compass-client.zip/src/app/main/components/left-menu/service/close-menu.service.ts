import {Injectable} from '@angular/core';
import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class CloseMenuService {
  private subject = new Subject<any>();

  hamburgerClick(message: string) {

    this.subject.next({text: message});
  }

  setHamburgerCloseIcon(message: string) {

    this.subject.next({text: message});

  }


  closeLeftMenu(): Observable<any> {
    return this.subject.asObservable();
  }

  hamburgerCloseIcon(): Observable<any> {
    return this.subject.asObservable();
  }
}
