import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {CloseMenuService} from './service/close-menu.service';

@Component({
  selector: 'app-left-menu',
  templateUrl: './left-menu.component.html',
  styleUrls: ['./left-menu.component.scss']
})
export class LeftMenuComponent implements OnInit, OnDestroy {
  message: any;
  subscription: Subscription;
  public adminMenuOpen: boolean;

  @Input() isActive: boolean;


  constructor(private closeMenuService: CloseMenuService) {

    this.subscription = this.closeMenuService.closeLeftMenu().subscribe(message => {
      this.adminMenuOpen = false;
    });

  }

  ngOnInit() {
    this.adminMenuOpen = false;

  }

  openAdminMenu() {
    this.adminMenuOpen = true;
  }

  closeAdminMenu() {
    this.adminMenuOpen = false;
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }

}
