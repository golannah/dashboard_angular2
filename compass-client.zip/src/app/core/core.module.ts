import {ModuleWithProviders, Optional, SkipSelf, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {HttpClientInterceptorService} from './services/http/http-client-interceptor.service';
import {HTTP_INTERCEPTORS} from '@angular/common/http';
import {Ng2Webstorage} from 'ngx-webstorage';
import {UnsavedEditModeChangesGuard} from '../shared/services/guards/unsaved-changes.guard';
import {LoggerService} from './services/logging/logger.service';
import {ConsoleLogService} from './services/logging/console-logger.service';
import {ToastrModule} from 'ngx-toastr';
import {LoaderService} from './services/loader/loader.service';
import {UserPreferencesService} from './services/user-preferences/user-preferences.service';
import {JwtDecode} from './pipes/jwt-decode/jwtdecode.pipe';
import {ShortDatePipe} from './pipes/date/short-date.pipe';
import {FullDatePipe} from './pipes/date/full-date.pipe';
import {CategoriesService} from './services/categories/categories.service';
import { FirstLetterCapitalizePipe } from './pipes/firstLetterCapitalize/first-letter-capitalize.pipe';
import {PluginsService} from './services/plugins/plugins.service';
import {DynamicStylesService} from './services/dynamic-styles/dynamic-styles.service';
import { CapitalizePipe } from './pipes/capitalize/capitalize.pipe';


@NgModule({
  imports: [
    CommonModule,
    Ng2Webstorage,
    ToastrModule.forRoot()
  ],
  declarations: [ShortDatePipe, FullDatePipe, FirstLetterCapitalizePipe, CapitalizePipe, JwtDecode],
  exports : [FullDatePipe, FirstLetterCapitalizePipe, ShortDatePipe, CapitalizePipe, JwtDecode],
  providers: [
    LoaderService,
    JwtDecode,
    UserPreferencesService,
    CategoriesService,
    PluginsService,
    DynamicStylesService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpClientInterceptorService,
      multi: true
    },
    {
      provide: LoggerService,
      useClass: ConsoleLogService
    }
  ]
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: [UnsavedEditModeChangesGuard]
    };
  }
}
