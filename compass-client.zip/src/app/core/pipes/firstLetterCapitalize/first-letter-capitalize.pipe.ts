import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'firstLetterCapitalize'
})
export class FirstLetterCapitalizePipe implements PipeTransform {

  transform(value: any) {
    if (value) {
      if (value.search('_') !== -1) {
        const splitStr = value.toLowerCase().split('_');
        value =  splitStr.join(' ');
      }
      return value.charAt(0).toUpperCase();
    }
    return value;
  }

}
