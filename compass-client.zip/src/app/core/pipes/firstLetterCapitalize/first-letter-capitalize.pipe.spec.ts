import { FirstLetterCapitalizePipe } from './first-letter-capitalize.pipe';

describe('FirstLetterCapitalizePipe', () => {
  it('create an instance', () => {
    const pipe = new FirstLetterCapitalizePipe();
    expect(pipe).toBeTruthy();
  });
});
