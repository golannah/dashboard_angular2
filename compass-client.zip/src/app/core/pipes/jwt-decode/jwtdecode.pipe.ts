import { Pipe, PipeTransform } from '@angular/core';
import * as jwtDecode from 'jwt-decode';

@Pipe({ name: 'jwtdecode' })
export class JwtDecode implements PipeTransform {
  transform(token: string): any {
    if (!token) {
      return token;
    }
    return jwtDecode(token);
  }
}
