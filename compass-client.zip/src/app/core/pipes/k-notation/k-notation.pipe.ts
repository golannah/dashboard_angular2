import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'kNotation'
})
export class KNotationPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (!value || value.toString().split('.')[0].length < 4) {
      return value;
    }

    let strVal = value.toString().split('.')[0];

    const unitsAmount = Math.floor((strVal.length + 1) / 3);
    const unitsModulo = strVal.length % 3;
    const units = ['', 'K', 'M', 'G'];

    strVal = unitsModulo !== 0 ? [strVal.slice(0, unitsModulo), '.', strVal.slice(unitsModulo)].join('') : strVal;

    strVal = (strVal.length < 4) ? strVal : strVal.substring(0, strVal.length - 3 * (unitsAmount - 1) - unitsModulo) + units[unitsAmount];

    return strVal.indexOf('.') > 0 ? strVal.split('0' + units[unitsModulo]).join(units[unitsModulo]) : strVal;
  }

}
