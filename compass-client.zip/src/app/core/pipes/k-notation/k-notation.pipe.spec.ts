import { KNotationPipe } from './k-notation.pipe';

describe('KNotationPipe', () => {
  it('create an instance', () => {
    const pipe = new KNotationPipe();
    expect(pipe).toBeTruthy();
  });
});
