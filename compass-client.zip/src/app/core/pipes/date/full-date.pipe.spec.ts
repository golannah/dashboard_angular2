import { FullDatePipe } from './full-date.pipe';

describe('FullDatePipe', () => {
  it('create an instance', () => {
    const pipe = new FullDatePipe();
    expect(pipe).toBeTruthy();
  });
});
