import {ListInterface} from './list-interface';

export abstract class List<T> implements  ListInterface {
  public first: boolean;
  public last: boolean;
  public numberOfElements: boolean;
  public sort: string;
  public totalElements: number;
  public totalPages: number;
  abstract  content: T[];
}
