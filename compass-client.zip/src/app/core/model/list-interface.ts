export interface ListInterface {
  first: boolean;
  last: boolean;
  numberOfElements: boolean;
  sort: string;
  totalElements: number;
  totalPages: number;
  content: any;
}
