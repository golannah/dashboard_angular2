export class Asset {
  public ip: string;
}
