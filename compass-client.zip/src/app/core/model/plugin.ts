export class Plugin {
  public label: string;
  public icon: string;
  public color?: string;
  public value: number;
}
