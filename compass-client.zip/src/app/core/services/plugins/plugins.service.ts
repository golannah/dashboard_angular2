import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Plugin} from '../../model/plugin';
import {filter, conforms, map, pick} from 'lodash';
import {environment} from '../../../../environments/environment';

@Injectable()
export class PluginsService {

  private pluginsList: Plugin[]  = null;

  constructor(private httpClient: HttpClient) {
    const url = `${environment.compassApiBaseUrl}/root/plugins/details`;
    this.httpClient.get<Plugin[]>(url).subscribe(
      (data) => {
        this.pluginsList =  data;
      },
      err => console.log(err)
    );
  }

  getPlugins() {
    const url = `${environment.compassApiBaseUrl}/root/plugins/details`;
    return this.httpClient.get<Plugin[]>(url);
  }
   getPluginProperties(pluginIdsArray: number[], pluginProperties: string[]): string[] {
    const plugins = filter(this.pluginsList, conforms({
      'value': (value) => {
        return pluginIdsArray.indexOf(value) > -1;
      }
    }));

    return map(plugins, cat => pick(cat, pluginProperties)) as string[];
  }

}
