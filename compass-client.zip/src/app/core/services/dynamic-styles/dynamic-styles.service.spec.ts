import { TestBed, inject } from '@angular/core/testing';

import { DynamicStylesService } from './dynamic-styles.service';

describe('DynamicStylesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DynamicStylesService]
    });
  });

  it('should be created', inject([DynamicStylesService], (service: DynamicStylesService) => {
    expect(service).toBeTruthy();
  }));
});
