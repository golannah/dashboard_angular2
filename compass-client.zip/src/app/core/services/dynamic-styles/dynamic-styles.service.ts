import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../../environments/environment';

@Injectable()
export class DynamicStylesService {

  constructor(private http: HttpClient) {
  }


  setDynamicStyles() {

    this.getStylesJson()
      .subscribe(
        (data) => {
          const style = document.createElement('style');
          style.type = 'text/css';
          style.innerHTML = this.jsonToCss(data);
          document.getElementsByTagName('head')[0].appendChild(style);
        },
        err => console.log(err)
      );
  }

  jsonToCss(json) {
    const selectors = Object.keys(json);
    return selectors.map((selector) => {
      const definition = json[selector];
      const rules = Object.keys(definition);
      const result = rules.map((rule) => {
          return `${rule}:${definition[rule]}`;
        }
      ).join(';');
      return `${selector}{${result}}`;
    }).join('\n');
  }

  getStylesJson() {
    const url = `${environment.compassApiBaseUrl}/styles`;
    return this.http.get(url);
  }


}
