import {Injectable, Injector} from '@angular/core';
import {
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpEvent,
  HttpErrorResponse, HttpHeaders, HttpResponse
} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import {environment} from '../../../../environments/environment';
import {flow} from 'lodash';
import {BsModalService} from 'ngx-bootstrap/modal';
import {BsModalRef} from 'ngx-bootstrap/modal/bs-modal-ref.service';
import {Router} from '@angular/router';
import {LoggerService} from '../logging/logger.service';
import {ModalComponent} from '../../../shared/components/modal-component/modal-component.component';
import {LoaderService} from '../loader/loader.service';
import {LocalStorageService} from 'ngx-webstorage';


@Injectable()
export class HttpClientInterceptorService implements HttpInterceptor {

  private modalService: BsModalService;
  private routerService: Router;
  private loggerService: LoggerService;
  private bsModalRef: BsModalRef;
  private HTTP_FORBIDDEN = 403;
  HTTP_UNAUTHORIZED = 401;
  constructor(private logger: LoggerService,
              private injector: Injector,
              private loaderService: LoaderService,
              private localStorageService: LocalStorageService) {
    /**
     * init logic goes here
     */
  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const authHeader = this.getAuthorizationHeader();
    const requestIdHeader: any = this.getRequestIdHeader();
    let addHeaderFunc: Function;
    if (authHeader) {
      addHeaderFunc = flow((currentReq: HttpRequest<any>) => {
          return currentReq.headers.set(requestIdHeader.name, requestIdHeader.value);
        },
        (headers: HttpHeaders) => {
          return headers.set(authHeader.name, authHeader.value);
        });
    } else {
      addHeaderFunc = (currentReq: HttpRequest<any>) => {
        return currentReq.headers.set(requestIdHeader.name, requestIdHeader.value);
      };
    }
    const newReq = req.clone({
      headers: addHeaderFunc(req)
    });

    this.showLoader();

    return next.handle(newReq).do((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse) {
        // this.logger.error('Http request done', event);
        this.onEnd();
      }
    }, (err: any) => {
      if (err instanceof HttpErrorResponse) {
        this.handleError(err);
        this.onEnd();
      }
    });
  }

  private get modal(): BsModalService {
    if (!this.modalService) {
      this.modalService = this.injector.get(BsModalService);
    }
    return this.modalService;
  }

  private get router(): Router {
    if (!this.routerService) {
      this.routerService = this.injector.get(Router);
    }
    return this.routerService;
  }

  openErrorModal(error: HttpErrorResponse) {
    this.bsModalRef = this.modal.show(ModalComponent);
    this.bsModalRef.content.title = 'Error occured';
    this.bsModalRef.content.innerHtml = `<div>${error.message}</div>`;
  }

  handleError(error: HttpErrorResponse) {
    if (error.status === this.HTTP_FORBIDDEN || error.status === this.HTTP_UNAUTHORIZED) {
      this.router.navigate(['']);
      this.localStorageService.clear('token');
    } else {
      this.openErrorModal(error);
    }
  }

  getAuthorizationHeader() {
    const authentication: any = environment.authentication;
    const headerName: string = authentication.headerName;
    const headerValue = this.localStorageService.retrieve('token') || null;
    if (headerValue) {
      return {name: headerName, value: headerValue};
    }
    return null;
  }

  getRequestIdHeader() {
    // get request id name
    const authentication: any = environment.authentication;
    const requestIdName: string = authentication.requestIdName;
    const requestId = this.getRequestId();
    return {name: requestIdName, value: requestId};
  }

  getRequestId() {
    return Math.random().toString(36).slice(2).concat(Math.random().toString(36).slice(2)).substring(1, 32);
  }

  private onEnd(): void {
    this.hideLoader();
  }

  private showLoader(): void {
    this.loaderService.show();
  }

  private hideLoader(): void {
    this.loaderService.hide();
  }

}
