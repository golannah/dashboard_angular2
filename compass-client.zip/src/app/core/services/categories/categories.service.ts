import {Injectable} from '@angular/core';
import {Category} from '../../model/category';
import {filter, conforms, map, pick} from 'lodash';
import {environment} from '../../../../environments/environment';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class CategoriesService {

  public categoriesList;

  constructor(private http: HttpClient) {
    this.getAllCategories()
      .subscribe(
        (data) => {
          this.categoriesList = data;
        },
        err => console.log(err)
      );
  }


  public getCategoryProperties(categoryIdsArray: number[]): string[] {

    const categories = filter(this.categoriesList, conforms({
      'value': (id) => {
        return map(categoryIdsArray, 'category').indexOf(id) > -1;
      }
    }));

    // TODO: check about icon property:will it derive from 'displayName'?
    // return map(categories, cat => pick(cat, categoryProperties)) as any[];

     return map(categories, 'displayName');
  }

  public getAllCategories() {
    const url = `${environment.compassApiBaseUrl}/threats/threats/categories`;
    return this.http.get(url);
  }

}
