import { Injectable } from '@angular/core';

@Injectable()
export class LoggerService {
  public error( ...args: any[] ): void {
    // ... the default logger does no work.
  }
  public log( ...args: any[] ): void {
    // ... the default logger does no work.
  }

  public warn( ...args: any[] ): void {
    // ... the default logger does no work.
  }

}
