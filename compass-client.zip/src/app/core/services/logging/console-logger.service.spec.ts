import { TestBed, inject } from '@angular/core/testing';

import { ConsoleLogService } from './console-logger.service';


describe('ConsoleLoggerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConsoleLogService]
    });
    spyOn(console, 'error');
    spyOn(console, 'warn');
    spyOn(console, 'log');
  });

  it('should be created', inject([ConsoleLogService], (service: ConsoleLogService) => {
    expect(service).toBeTruthy();
  }));

  it('console error,warn and log is called', inject([ConsoleLogService], (service: ConsoleLogService) => {
     service.error('Error');
     service.warn('Warning');
     service.log('Log');
     expect(console.error).toHaveBeenCalled();
     expect(console.warn).toHaveBeenCalled();
     expect(console.log).toHaveBeenCalled();
  }));
});
