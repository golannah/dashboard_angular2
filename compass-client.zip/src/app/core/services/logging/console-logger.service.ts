import {noop} from 'rxjs/util/noop';
declare const console: any;
import { ILogger } from './ilogger';
import {get as lodashGet, toArray as lodashToArray} from 'lodash';
import {environment} from '../../../../environments/environment';

export class ConsoleLogService implements ILogger {
  private consoleLoggingConfig = environment.logging.console;
  public error( ...args): void {
      this.excuteConsoleCommand('error', args);
   }
   public log( ...args): void {
     this.excuteConsoleCommand('log', args);
   }
   public warn( ...args): void {
     this.excuteConsoleCommand('warn', args);
   }

  private excuteConsoleCommand(method: string, args: any): void {
    const isEnabledFunction = lodashGet(this.consoleLoggingConfig, `${method}.enabled`, false);
    if (isEnabledFunction) {
      const consoleFunc = lodashGet(console, method, noop);
      consoleFunc.apply(console, lodashToArray(args));
    }
  }

}
