import {Injectable} from '@angular/core';
import {JwtDecode} from '../../pipes/jwt-decode/jwtdecode.pipe';
import {LocalStorageService} from 'ngx-webstorage';

@Injectable()
export class UserPreferencesService {


  private _rolesDetails: Roles;
  private _userDetails: UserDetails;
  private _tokenDetails: TokenDetails;
  private _userPreferences: UserPreferences;


  constructor(private jwtDecoder: JwtDecode, private localSt: LocalStorageService) {
    if (localSt.retrieve('userPreferences')) {
      this.userPreferences = localSt.retrieve('userPreferences');
    }
  }

  decodeToken(token: string) {

    const decodedToken = this.jwtDecoder.transform(token);
    this.assignTokenValues(decodedToken);
  }

  assignTokenValues(decodedToken: any) {

    const userDetails: UserDetails = {
      tenant: decodedToken['tenant'],
      oid: decodedToken['oid'],
      name: decodedToken['name'],
      emailAddress: decodedToken['emailAddress']
    };

    const tokenDetails: TokenDetails = {
      creationTime: decodedToken['emailAddress'],
      expiryTime: decodedToken['exp'],
      refreshTime: decodedToken['refreshTime']
    };

    const roles: Roles = {
      roles: decodedToken['roles']
    };

    this.rolesDetails = roles;
    this.userDetails = userDetails;
    this.tokenDetails = tokenDetails;
    this.userPreferences = {
      rolesDetails: roles,
      userDetails: userDetails,
      tokenDetails: tokenDetails
    };

  }


  get rolesDetails(): Roles {
    console.log(this.localSt.retrieve('userPreferences'));
    return this._rolesDetails || this.localSt.retrieve('userPreferences').rolesDetails;
  }

  set rolesDetails(value: Roles) {
    this._rolesDetails = value;
  }

  get userDetails(): UserDetails {
    return this._userDetails || this.localSt.retrieve('userPreferences').userDetails;
  }

  set userDetails(value: UserDetails) {
    this._userDetails = value;
  }

  get tokenDetails(): TokenDetails {
    return this._tokenDetails || this.localSt.retrieve('userPreferences').tokenDetails;
  }

  set tokenDetails(value: TokenDetails) {
    this._tokenDetails = value;
  }

  get userPreferences(): UserPreferences {
    return this._userPreferences || this.localSt.retrieve('userPreferences');
  }

  set userPreferences(value: UserPreferences) {
    this._userPreferences = value;
  }


}

interface Roles {
  roles: string[];
}

interface UserDetails {
  tenant: string;
  oid: string;
  name: string;
  emailAddress: string;
}

interface TokenDetails {
  creationTime: string;
  expiryTime: string;
  refreshTime: string;
}

interface UserPreferences {
  rolesDetails: Roles;
  userDetails: UserDetails;
  tokenDetails: TokenDetails;
}
