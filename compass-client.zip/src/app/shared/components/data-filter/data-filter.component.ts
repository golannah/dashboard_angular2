import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';

@Component({
  selector: 'app-data-filter',
  templateUrl: './data-filter.component.html',
  styleUrls: ['./data-filter.component.scss']
})
export class DataFilterComponent implements OnInit {

  @Output() public applyAction = new EventEmitter();
  @Output() public resetToDefault = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  resetToDefaultClicked() {
      this.resetToDefault.emit();
  }
  applyClicked() {
    this.applyAction.emit();
  }
}
