import { Component, OnInit } from '@angular/core';
import {CategoriesService} from '../../../core/services/categories/categories.service';
import {SelectItem} from 'primeng/primeng';
import {map} from 'lodash';

@Component({
  selector: 'app-category-filter',
  templateUrl: './category-filter.component.html',
  styleUrls: ['./category-filter.component.scss']
})
export class CategoryFilterComponent implements OnInit {

  public selectedCategories: SelectItem [];
  public categoriesList: SelectItem[];
  public categories: any;
  constructor(private categoriesService: CategoriesService) {}
  ngOnInit() {
    this.categoriesService.getAllCategories()
      .subscribe(
        (data) => {
          this.categories = data;
          this.categoriesList = <SelectItem []> map(this.categories, (category: any) => {
            const selectItem = {
              label : category.displayName,
              value : category
            }
            return selectItem;

          });
        },
        err => console.log(err)
      );

  }

  getSelectedCategories() {
    return map(this.selectedCategories, (category: any) =>   category.value  );
  }

}
