import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-range',
  templateUrl: './event-range.component.html',
  styleUrls: ['./event-range.component.scss']
})
export class EventRangeComponent implements OnInit {

  @Input() eventRange;

  constructor() {

  }

  ngOnInit() {

  }



}
