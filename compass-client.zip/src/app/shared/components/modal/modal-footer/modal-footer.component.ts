import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap';
import {ThreatBase} from '../../../../main/features/threats/model/threat.base';

@Component({
  selector: 'app-modal-footer',
  templateUrl: './modal-footer.component.html',
  styleUrls: ['./modal-footer.component.scss']
})
export class ModalFooterComponent implements OnInit {

  @Input() public title: string;
  @Input() public bsModalRef: BsModalRef;
  @Output() public applyAction = new EventEmitter();
  public threat: ThreatBase;

  constructor() { }

  applyClicked() {
    this.applyAction.emit(this.threat);
  }

  ngOnInit() {
  }

}
