import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import * as moment from 'moment';
import {Ranges} from '../../../main/features/dashboard/enums/date-range.enum';

@Component({
  selector: 'app-date-range-picker',
  templateUrl: './date-range-picker.component.html',
  styleUrls: ['./date-range-picker.component.scss']
})
export class DateRangePickerComponent implements OnInit {

  @Input() dateRangeOptions: any;
  @Output() dateRangeSelected = new EventEmitter();
  @Input() flavor = false;
  public dateRangeLabel = 'Last 7 Days ';
  public dateRange: any = {};

  constructor() {
  }

  selectedDate(value: any, datepicker?: any) {

    datepicker.start = value.start;
    datepicker.end = value.end;

    this.dateRange.start = value.start;
    this.dateRange.end = value.end;
    this.dateRange.label = value.label;

    if (this.dateRange.label !== 'Custom Range') {
      this.dateRangeLabel = this.dateRange.label;
    } else {
      this.dateRangeLabel = moment(this.dateRange.start).format('MM/DD/YYYY') +
        ' - ' +
        moment(this.dateRange.end).format('MM/DD/YYYY');
    }

    this.dateRange.label = this.dateRangeLabel;
    this.dateRangeSelected.emit(this.dateRange);
  }

  getSelectedRange() {
    const startTimestamp = this.dateRange.start;
    const endTimestamp = this.dateRange.end;
    const selectedRange = {
      startTimestamp,
      endTimestamp,
    };
    return selectedRange;
  }

  ngOnInit() {
    if (!this.dateRangeOptions) {
      this.dateRangeOptions = {
        locale: {format: 'YYYY-MM-DD'},
        alwaysShowCalendars: true,
        startDate: Ranges.Last7Days,
        endDate: Ranges.TodayEnd,
        ranges: {
          'Yesterday': [Ranges.YesterdayStart, Ranges.TodayEnd],
          'Last 3 Days': [Ranges.Last3Days, Ranges.TodayEnd],
          'Last 7 Days': [Ranges.Last7Days, Ranges.TodayEnd],
          'Last Month': [Ranges.LastMonth, Ranges.TodayEnd],
        },
        opens: 'left'
      };
    } else {
      switch (moment(this.dateRangeOptions.startDate).valueOf()) {
        case moment(Ranges.TodayStart).valueOf():
          this.dateRangeLabel = 'Today ';
          break;
        case moment(Ranges.YesterdayStart).valueOf():
          this.dateRangeLabel = 'Yesterday ';
          break;
        case moment(Ranges.Last3Days).valueOf():
          this.dateRangeLabel = 'Last 3 Days ';
          break;
        case moment(Ranges.Last7Days).valueOf():
          this.dateRangeLabel = 'Last 7 Days ';
          break;
        case moment(Ranges.LastMonth).valueOf():
          this.dateRangeLabel = 'Last Month ';
          break;
      }
    }
  }
}
