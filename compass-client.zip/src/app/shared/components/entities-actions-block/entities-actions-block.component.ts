import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-entities-actions-block',
  templateUrl: './entities-actions-block.component.html',
  styleUrls: ['./entities-actions-block.component.scss']
})
export class EntitiesActionsBlockComponent implements OnInit {

  @Input() totalText: string;
  @Input() controlsConfig;

  @Output() shareData = new EventEmitter();
  @Output() searchData = new EventEmitter();
  @Output() showFilter = new EventEmitter();
  private filterOpen = false;
  public query: '';

  constructor() {
  }

  ngOnInit() {
    this.controlsConfig = this.controlsConfig || {
      search: true, filter: true, download: true, toggleView: false
    };
  }

  shareDataClicked() {
    /// this.shareData.emit();
  }

  searchClicked() {
    this.searchData.emit(this.query);
  }

  triggerFilter() {
    this.filterOpen = !this.filterOpen;
    this.showFilter.emit(this.filterOpen);
  }

}
