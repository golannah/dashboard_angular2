import {Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {ListInterface} from '../../../core/model/list-interface';
import { times } from 'lodash';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit, OnChanges {

  @Input() paginatedList: ListInterface;
  @Output() pageChanged = new EventEmitter<number>();

  public rows: number;
  public totalElements: number;
  public totalPages: number;
  public pages = [];
  constructor() {}

  ngOnInit() {

  }
  ngOnChanges() {
    this.pages = [];
    this.totalElements = this.paginatedList.totalElements;
    this.rows = this.totalElements >= 100 ? 100 : this.totalElements;
    this.totalPages = (this.totalElements / this.rows) || 1;
    let counter = 1;
    let fromValue = counter;
    times(this.totalPages, () => {
      const page = {label: `${fromValue}-${counter * this.rows}`, value: counter};
      this.pages.push(page);
      fromValue = (counter * this.rows) + 1;
      counter++;
    });
  }
   public onPageChange(page) {
     this.pageChanged.emit(page);
  }

}
