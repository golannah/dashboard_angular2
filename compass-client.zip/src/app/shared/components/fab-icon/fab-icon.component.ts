import {Component, EventEmitter, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-fab-icon',
  templateUrl: './fab-icon.component.html',
  styleUrls: ['./fab-icon.component.scss']
})
export class FabIconComponent implements OnInit {

  @Output() public fabIconAction = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  fabIconClicked() {
    this.fabIconAction.emit();
  }

}
