import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FabIconComponent } from './fab-icon.component';

describe('FabIconComponent', () => {
  let component: FabIconComponent;
  let fixture: ComponentFixture<FabIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FabIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FabIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
