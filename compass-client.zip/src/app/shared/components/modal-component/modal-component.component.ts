import {Component, Injector, OnInit} from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

@Component({
  selector: 'app-modal-component',
  templateUrl: './modal-component.component.html',
  styleUrls: ['./modal-component.component.scss']
})
export class ModalComponent implements OnInit {

  public title: string;
  public innerHtml  = '<div></div>';
  public bsModalRef: BsModalRef;
  constructor(private injector: Injector) {
    this.bsModalRef = this.injector.get(BsModalRef);
  }

  ngOnInit() {
  }

}
