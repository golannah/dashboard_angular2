import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarColumnComponent } from './bar-column.component';

describe('BarColumnComponent', () => {
  let component: BarColumnComponent;
  let fixture: ComponentFixture<BarColumnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarColumnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
