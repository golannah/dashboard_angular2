import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-bar-column',
  templateUrl: './bar-column.component.html',
  styleUrls: ['./bar-column.component.scss']
})
export class BarColumnComponent implements OnInit {

  @Input() barData;
  @Output() barClickedEmitter = new EventEmitter();

  constructor() {
  }

  onBarClicked() {
    this.barClickedEmitter.emit({
      name: this.barData['displayName'],
      value: this.barData['count']
    });
  }

  ngOnInit() {
  }

}
