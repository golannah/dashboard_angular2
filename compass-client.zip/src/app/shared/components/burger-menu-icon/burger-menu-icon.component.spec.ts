import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BurgerMenuIconComponent } from './burger-menu-icon.component';

describe('BurgerMenuIconComponent', () => {
  let component: BurgerMenuIconComponent;
  let fixture: ComponentFixture<BurgerMenuIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BurgerMenuIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BurgerMenuIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
