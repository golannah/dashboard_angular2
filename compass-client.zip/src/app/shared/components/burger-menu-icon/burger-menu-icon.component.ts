import {Component, OnDestroy} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {CloseMenuService} from '../../../main/components/left-menu/service/close-menu.service';


@Component({
  selector: 'app-burger-menu-icon',
  templateUrl: './burger-menu-icon.component.html',
  styleUrls: ['./burger-menu-icon.component.scss']
})
export class BurgerMenuIconComponent implements OnDestroy {

  public isOpen = false;
  subscription: Subscription;

  constructor(private closeMenuService: CloseMenuService) {

    this.subscription = this.closeMenuService.hamburgerCloseIcon().subscribe(message => {

      if (this.isOpen) {
        this.isOpen = false;
        this.closeMenuService.setHamburgerCloseIcon('close');
      }
    });

  }

  closeLeftMenu() {

    this.isOpen = !this.isOpen;

  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }
}
