import { Component, OnInit } from '@angular/core';
import {ModalComponent} from '../../src/app/shared/components/modal-component/modal-component.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/modal-options.class';

@Component({
  selector: 'app-ngx-boostrap-modal',
  templateUrl: './ngx-boostrap-modal.component.html',
  styleUrls: ['./ngx-boostrap-modal.component.scss']
})
export class NgxBoostrapModalComponent implements OnInit {

  private bsModalRef: BsModalRef;
  constructor(private modalService: BsModalService) { }

  openModalWithComponent() {
    const list = ['Open a modal with component', 'Pass your data', 'Do something else', '...'];
    this.bsModalRef = this.modalService.show(ModalComponent);
    this.bsModalRef.content.title = 'Modal with component';
    this.bsModalRef.content.list = list;
    this.bsModalRef.content.onClick = () => {
      alert('parant callback');
    }
    setTimeout(() => {
      list.push('PROFIT!!!');
    }, 2000);
  }

  ngOnInit() {
  }

}
