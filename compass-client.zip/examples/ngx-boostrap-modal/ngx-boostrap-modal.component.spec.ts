import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgxBoostrapModalComponent } from './ngx-boostrap-modal.component';

describe('NgxBoostrapModalComponent', () => {
  let component: NgxBoostrapModalComponent;
  let fixture: ComponentFixture<NgxBoostrapModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgxBoostrapModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgxBoostrapModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
