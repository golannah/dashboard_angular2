import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from '../src/app/shared/shared.module';
import { NgxBoostrapModalComponent } from './ngx-boostrap-modal/ngx-boostrap-modal.component';
import {ModalModule} from 'ngx-bootstrap';
import {TranslationExampleComponent} from './services/translation-example/translation-example.component';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {ModalComponent} from '../src/app/shared/components/modal-component/modal-component.component';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, '../../src/assets/i18n/', '.json');
}

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ModalModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  declarations: [
    NgxBoostrapModalComponent,
    TranslationExampleComponent
  ]
})
export class ExamplesModule { }
