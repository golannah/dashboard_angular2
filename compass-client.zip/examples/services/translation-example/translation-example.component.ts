import { Component, OnInit } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Component({
  selector: 'app-tranlation-example',
  templateUrl: './translation-example.component.html',
  styleUrls: ['./translation-example.component.scss']
})
export class TranslationExampleComponent implements OnInit {

  constructor(private translate: TranslateService) {
    translate.addLangs(["en", "fr"]);
    translate.setDefaultLang('en');

    translate.use('en');
  }

  ngOnInit() {

  }

}
