import {LocalStorageService} from "ngx-webstorage";

export class localStorageUsage {
  constructor(private localSt: LocalStorageService){

    //store value on local storage
    this.localSt.store('foo', 'bar');

    //observe changes on local storage properties
    this.localSt.observe('foo')
      .subscribe((newValue) => {
        alert(newValue);
      });

    //retrieve values from local storage
    console.log(this.localSt.retrieve('foo'));

  }
}
